<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>
<head>
<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7" />
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
<title><?php wp_title('&laquo;', true, 'right'); ?> <?php bloginfo('name'); ?></title>
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
<?php if ( is_singular() ) wp_enqueue_script( 'comment-reply' );?>
<?php wp_head(); ?>
<?php $logo = get_option('ka_sitelogo'); $toolbar = get_option('ka_toolbar'); $toolbar_color = get_option('ka_toolbar_color'); ?>
<!--[if lte IE 8]><link rel="stylesheet" type="text/css" href="<?php bloginfo('template_url'); ?>/css/lt8.css" media="screen"/><![endif]-->
</head>
<body>
<div id="wrapper" <?php if (is_page_template('template-homepage-3D.php') || is_page_template('template-homepage-jquery-2.php')) {echo 'class="big-banner"';} ?>>
<div id="header" <?php if (is_page_template('template-homepage-3D.php')){echo "style='height: 560px;'";} ?>>
<?php if ($toolbar == "true"){ ?>
<div class="top-block" <?php if ($toolbar_color != '') {echo "style=\"background: " . $toolbar_color . " !important;\"";} ?>>
<div class="top-holder">
    <div class="sub-nav">
    <ul><?php dynamic_sidebar("Toolbar - Left Side"); ?></ul>
    </div><!-- end sub-nav -->

    <div class="sub-nav2">
    <?php dynamic_sidebar("Toolbar - Right Side"); ?>
    </div><!-- end sub-nav2 -->
</div><!-- end top-holder -->
</div><!-- end top-block -->
<?php } ?>

<div class="header-holder">
<div class="rays">
<div class="header-area<?php if (is_search()) {echo ' search-header';} ?><?php if (is_404()) {echo ' error-header';} ?><?php if (is_page_template('template_sitemap.php')) {echo ' search-header';} ?>">
<a href="<?php echo home_url(); ?>" class="logo"><img src="<?php echo $logo; ?>" alt="<?php bloginfo('name'); ?>" /></a>



<?php if (function_exists('wp_nav_menu')) {	
echo '<ul id="menu-main-nav">';
wp_nav_menu( array(
 'container' =>false,
 'theme_location' => 'Primary Navigation',
 'sort_column' => 'menu_order',
 'menu_class' => '',
 'echo' => true,
 'before' => '',
 'after' => '',
 'link_before' => '',
 'link_after' => '',
 'depth' => 0,
 'walker' => new description_walker())
 );
echo '</ul>';} ?>
