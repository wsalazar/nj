<?php
/*
Template Name: Portfolio :: 1 Column + No Nav
*/
?>
<?php get_header(); ?>
<?php include (TEMPLATEPATH . '/functions/content/tools.php'); ?>
			
			
			
<div class="main-holder">
<div id="content" class="portfolio_full_width">
<?php
remove_filter('pre_get_posts','wploop_exclude');
$portfolio_count = get_post_meta($post->ID, "_sc_port_count_value", $single = true);
$posts_p_p = stripslashes($portfolio_count);
$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
$category_id = get_post_meta($post->ID, '_multiple_portfolio_cat_id', true);
$query_string ="posts_per_page=$posts_p_p&cat=$category_id&paged=$paged&order=ASC";
query_posts($query_string);

$count = 0;
$col = 0;

if (have_posts()) : while (have_posts()) : the_post();

  $count++;
	  $col ++;
	  $mod = ($count % 3 == 0) ? 0 : 3 - $count % 3;
?>
            
<div class="portfolio_wrap">
<div class="portfolio_one_column_last">
<?php if ( get_post_meta($post->ID, '_portimage_thumb_value', true) ) { ?>
<div class="port_img_one">
<div class="preload preload_one">
<a href="<?php echo get_post_meta($post->ID, "_portimage_full_value", $single = true); ?>" class="attachment-fadeIn" rel="prettyPhoto[g1]"><img src="<?php echo bloginfo('template_directory'); ?>/images/_global/img-zoom-1.png" style="position:absolute; display: none;" alt="<?php the_title(); ?>" /><img src="<?php bloginfo('template_directory'); ?>/functions/thumbs.php?src=<?php echo get_post_meta($post->ID, "_portimage_thumb_value", $single = true); ?>&amp;h=563&amp;w=703&amp;zc=1" alt="<?php the_title(); ?>" width="703" height="563" /></a>
</div><!-- end preload_one -->
</div><!-- end port_img_one -->
<?php } ?>
</div><!-- end portfolio_one_column -->


<div class="portfolio_one_column">
<h3><?php the_title(); ?></h3>
<?php the_content(); ?>
</div><!-- end portfolio_one_column -->
</div><!-- end portfolio_wrap -->

<div class="port_sep"><hr /><a href="#" class="link-top">top</a></div><!-- end port_sep -->

<?php endwhile; endif; ?>
<?php  wp_pagenavi();  ?>
</div><!-- end content -->
</div><!-- end main-holder -->
</div><!-- main-area -->




<?php get_footer(); ?>