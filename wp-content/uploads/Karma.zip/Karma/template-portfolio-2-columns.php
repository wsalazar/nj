<?php
/*
Template Name: Portfolio :: 2 Columns
*/
?>
<?php get_header(); ?>
<?php include (TEMPLATEPATH . '/functions/content/tools.php'); ?>
			
			
			
<div class="main-holder">
<?php
if (function_exists('wp_nav_menu')) {
$menu_args = array('walker' => new sub_nav_walker(),);
echo '<div id="horizontal_nav">';
wp_nav_menu($menu_args);
echo '</div><!-- end sub_nav -->';
};?>




<div id="content" class="content_full_width portfolio_layout">
<?php
remove_filter('pre_get_posts','wploop_exclude');
$portfolio_count = get_post_meta($post->ID, "_sc_port_count_value", $single = true);
$posts_p_p = stripslashes($portfolio_count);
$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
$category_id = get_post_meta($post->ID, '_multiple_portfolio_cat_id', true);
$query_string ="posts_per_page=$posts_p_p&cat=$category_id&paged=$paged&order=ASC";
query_posts($query_string);

$count = 0;
$col = 0;

if (have_posts()) : while (have_posts()) : the_post();

  $count++;
	  $col ++;
	  $mod = ($count % 2 == 0) ? 0 : 2 - $count % 2;
?>
            
            
         
<div class="one_half<?php if($col == 2){  echo '_last'; $col = 0; } ?>">
<?php if ( get_post_meta($post->ID, '_portimage_thumb_value', true) ) { ?>
<div class="portfolio_content_top">
<div class="port_img_two">
<div class="preload preload_two">
<a href="<?php echo get_post_meta($post->ID, "_portimage_full_value", $single = true); ?>" class="attachment-fadeIn" rel="prettyPhoto[g1]"><img src="<?php echo bloginfo('template_directory'); ?>/images/_global/img-zoom-2.png" style="position:absolute; display: none;" alt="<?php the_title(); ?>" /><img src="<?php bloginfo('template_directory'); ?>/functions/thumbs.php?src=<?php echo get_post_meta($post->ID, "_portimage_thumb_value", $single = true); ?>&amp;h=234&amp;w=437&amp;zc=1" alt="<?php the_title(); ?>" width="437" height="234" /></a>
</div><!-- end preload_two -->
</div><!-- end port_img_two -->
</div><!-- end portfolio_content_top -->

            
<div class="portfolio_content">
<h3><?php the_title(); ?></h3>
<?php the_content(); ?>
</div><!-- end portfolio_content -->
<?php } ?>
</div><!-- end portfolio_two_column -->   
<?php if ( $mod == 0 ){ echo '<br class="clear" />';}endwhile; endif;?>
<?php  wp_pagenavi();  ?>
</div><!-- end content -->
</div><!-- end main-holder -->
</div><!-- main-area -->




<?php get_footer(); ?>