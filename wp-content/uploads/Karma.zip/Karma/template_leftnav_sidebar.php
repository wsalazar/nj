<?php
/*
Template Name: Left Nav + Sidebar
*/
?>
<?php get_header(); ?>
<?php include (TEMPLATEPATH . '/functions/content/tools.php'); ?>



<div class="main-holder">
<?php
if (function_exists('wp_nav_menu')) {
$menu_args = array('walker' => new sub_nav_walker(),);
echo '<div id="sub_nav">';
wp_nav_menu($menu_args);
echo '</div><!-- end sub_nav -->';
};?>



<div id="content" class="content_sidebar content_right_sidebar">
<?php if(have_posts()) : while(have_posts()) : the_post(); the_content(); endwhile; endif; ?>
</div><!-- end content -->



<div id="sidebar">
<?php generated_dynamic_sidebar(); ?>
</div><!-- end sidebar -->
</div><!-- end main-holder -->
</div><!-- main-area -->



<?php get_footer(); ?>