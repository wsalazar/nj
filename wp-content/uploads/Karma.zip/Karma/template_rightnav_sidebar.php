<?php
/*
Template Name: Right Nav + Sidebar 
*/
?>
<?php get_header(); ?>
<?php include (TEMPLATEPATH . '/functions/content/tools.php'); ?>



<div class="main-holder">
<div id="sidebar" class="left_sidebar">
<?php generated_dynamic_sidebar(); ?>
</div><!-- end sidebar -->



<div id="content" class="content_sidebar content_right_sidebar">
<?php if(have_posts()) : while(have_posts()) : the_post(); the_content(); endwhile; endif; ?>
</div><!-- end content -->



<?php
if (function_exists('wp_nav_menu')) {
$menu_args = array('walker' => new sub_nav_walker(),);
echo '<div id="sub_nav" class="nav_right_sub_nav">';
wp_nav_menu($menu_args);
echo '</div><!-- end sub_nav -->';
};?>	



</div><!-- end main-holder -->
</div><!-- main-area -->



<?php get_footer(); ?>