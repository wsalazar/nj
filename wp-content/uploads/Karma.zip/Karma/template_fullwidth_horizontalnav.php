<?php
/*
Template Name: Full Width + Horizontal Nav
*/
?>
<?php get_header(); ?>
<?php include (TEMPLATEPATH . '/functions/content/tools.php'); ?>



<div class="main-holder">
<?php
if (function_exists('wp_nav_menu')) {
$menu_args = array('walker' => new sub_nav_walker(),);
echo '<div id="horizontal_nav">';
wp_nav_menu($menu_args);
echo '</div><!-- end sub_nav -->';
};?>	



<div id="content" class="content_full_width">
<?php if(have_posts()) : while(have_posts()) : the_post(); the_content(); endwhile; endif; ?>
</div><!-- end content -->
</div><!-- end main-holder -->
</div><!-- main-area -->



<?php get_footer(); ?>