<?php
/*
Template Name: Homepage :: jQuery
*/
?>
<?php get_header(); ?>


<div class="main-area home-main-area">
<div class="main-holder home-holder">
<div class="content_full_width">





<div class="home-bnr-jquery">
<ul>
<?php
remove_filter('pre_get_posts','wploop_exclude');
$jcycle_category = get_option('ka_jcycle_category');
$jcycle_category_id = get_cat_id($jcycle_category);
$query_string ="posts_per_page=100&cat=$jcycle_category_id";
query_posts($query_string);
if (have_posts()) : while (have_posts()) : the_post(); 
$jcycle_img = wp_get_attachment_url(get_post_thumbnail_id( $post->ID ));
$jcycle_url = get_post_meta($post->ID, '_jcycle_url_value', true);
?>
<li class="jqslider">
<div class="home-banner-main">
<h2><?php the_title(); ?></h2>
<?php the_content(); ?>
</div><!-- end home-banner-main -->
<?php if (has_post_thumbnail()) : ?>
<div class="home-banner-sub">
	<div class="home-banner-sub-content">
		<?php 
		if ($jcycle_url == ''){
		echo '<img src="'.KARMA_FRAMEWORK.'/thumbs.php?src='.$jcycle_img.'&amp;h=256&amp;w=404&amp;zc=1" alt="#" />';
		}else{
		echo '<a href="'.$jcycle_url.'"><img src="'.KARMA_FRAMEWORK.'/thumbs.php?src='.$jcycle_img.'&amp;h=256&amp;w=404&amp;zc=1" alt="#" /></a>';
		} ?>
        <div class="home-banner-bottom">&nbsp;</div>
	</div><!-- end home-banner-sub-content -->
</div><!-- end home-banner-sub -->
</li>
<?php endif; endwhile; endif; wp_reset_query(); ?>
</ul>
</div><!-- end home-bnr-jquery -->




<div class="home-jquery-content">
<?php if(have_posts()) : while(have_posts()) : the_post(); the_content(); endwhile; endif; ?>
</div><!-- end home-jquery-content -->
</div><!-- end content -->
</div><!-- end main-holder -->
</div><!-- main-area -->


<?php get_footer(); ?>