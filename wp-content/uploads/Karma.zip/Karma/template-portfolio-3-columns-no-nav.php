<?php
/*
Template Name: Portfolio :: 3 Columns + No Nav
*/
?>
<?php get_header(); ?>
<?php include (TEMPLATEPATH . '/functions/content/tools.php'); ?>
	
	
	
<div class="main-holder">
<div id="content" class="content_full_width portfolio_layout">
<?php
remove_filter('pre_get_posts','wploop_exclude');
$portfolio_count = get_post_meta($post->ID, "_sc_port_count_value", $single = true);
$posts_p_p = stripslashes($portfolio_count);
$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
$category_id = get_post_meta($post->ID, '_multiple_portfolio_cat_id', true);
$query_string ="posts_per_page=$posts_p_p&cat=$category_id&paged=$paged&order=ASC";
query_posts($query_string);

$count = 0;
$col = 0;

if (have_posts()) : while (have_posts()) : the_post();

  $count++;
	  $col ++;
	  $mod = ($count % 3 == 0) ? 0 : 3 - $count % 3;
?>
	
	
 
<div class="one_third<?php if($col == 3){  echo '_last'; $col = 0; } ?>">
<?php if ( get_post_meta($post->ID, '_portimage_thumb_value', true) ) { ?>
<div class="portfolio_content_top_three">
<div class="port_img_three">
<div class="preload preload_three">
<a href="<?php echo get_post_meta($post->ID, "_portimage_full_value", $single = true); ?>" class="attachment-fadeIn" rel="prettyPhoto[g1]"><img src="<?php echo bloginfo('template_directory'); ?>/images/_global/img-zoom-3.png" style="position:absolute; display: none;" alt="<?php the_title(); ?>" /><img src="<?php bloginfo('template_directory'); ?>/functions/thumbs.php?src=<?php echo get_post_meta($post->ID, "_portimage_thumb_value", $single = true); ?>&amp;h=145&amp;w=275&amp;zc=1" alt="<?php the_title(); ?>" width="275" height="145" /></a>
</div><!-- end preload_three -->
</div><!-- end port_img_three -->
</div><!-- end portfolio_content_top_three -->
    
	
<div class="portfolio_content">
<h3><?php the_title(); ?></h3>
<?php the_content(); ?>
</div><!-- end portfolio_content -->
<?php } ?>
</div><!-- end portfolio_three_column -->
<?php if ( $mod == 0 ){ echo '<br class="clear" />';}endwhile; endif;?>
<?php  wp_pagenavi();  ?>
</div><!-- end content -->
</div><!-- end main-holder -->
</div><!-- main-area -->




<?php get_footer(); ?>