<?php
/*
Template Name: Full Width + No Nav
*/
?>
<?php get_header(); ?>
<?php include (TEMPLATEPATH . '/functions/content/tools.php'); ?>



<div class="main-holder">
<div id="content" class="content_full_width">
<?php if(have_posts()) : while(have_posts()) : the_post(); the_content(); endwhile; endif; ?>
</div><!-- end content -->
</div><!-- end main-holder -->
</div><!-- main-area -->



<?php get_footer(); ?>