<?php get_header(); ?>
<?php
$ka_blogtitle = get_option('ka_blogtitle');
$ka_searchbar = get_option('ka_searchbar');
$ka_crumbs = get_option('ka_crumbs');
$ka_blogbutton = get_option('ka_blogbutton');
$ka_blogauthor = get_option('ka_blogauthor');
$ka_dragshare = get_option('ka_dragshare');
$ka_related_posts = get_option('ka_related_posts');
$ka_related_posts_title = get_option('ka_related_posts_title');
$ka_related_posts_count = get_option('ka_related_posts_count');

?>
<div class="main-area">
<div class="tools">
<div class="holder">
<div class="frame">
<h1><?php echo $ka_blogtitle; ?></h1>
<?php if ($ka_searchbar == "true"){include (TEMPLATEPATH . '/functions/content/searchform.php');} else {} ?>
<?php if ($ka_crumbs == "true"){ $bc = new simple_breadcrumb;} else {} ?>
</div><!-- end frame -->
</div><!-- end holder -->
</div><!-- end tools -->



<div class="main-holder">			
<div id="content" class="content_blog">
<?php if (have_posts()) : while (have_posts()) : the_post(); 
$ka_post_thumb = wp_get_attachment_url(get_post_thumbnail_id( $post->ID ));
?>
<div class="single_blog_wrap">
<div class="post_title">
<h1><?php the_title(); ?></h1>
<p><span>Posted by:</span> <?php the_author_posts_link(); ?></p>
</div><!-- end post_title -->


<?php if (has_post_thumbnail()) : ?>
<div class="post_content">
<div class="post_thumb">
<?php echo '<img src="'.KARMA_FRAMEWORK.'/thumbs.php?src='.$ka_post_thumb.'&amp;h=218&amp;w=538&amp;zc=1" alt="'.get_the_title().'" />';?>
</div><!-- end post_thumb -->
<?php else : ?> <div class="post_content">
<?php endif; ?>


<?php the_content(); ?>
<div class="post_date"><span class="day"><?php the_time('j'); ?></span><br /><span class="month"><?php echo strtoupper(get_the_time('M')); ?></span></div><!-- end post_date -->
<div class="post_comments"><a href="<?php echo the_permalink().'#post-comments'; ?>"><span><?php comments_number('0', '1', '%'); ?></span></a></div><!-- end post_comments -->


<?php if ($ka_related_posts == "true"){ 
echo '<br class="clear" /><br class="clear" />';
echo do_shortcode("[related_posts_content limit=\"".$ka_related_posts_count."\" title=\"".$ka_related_posts_title."\"]"); 

}?>

</div><!-- end post_content -->
<div class="post_footer">
<div class="post_cats">
	<p><span>Categories:</span> <?php the_category(', '); ?></p>
</div><!-- end post_cats -->
<?php if (get_the_tags()) : ?>
<div class="post_tags">
	<p><span>Tags:</span>  <?php the_tags('', ', '); ?></p>
</div><!-- end post_tags -->
<?php endif; ?>
</div><!-- end post_footer -->




<?php if ($ka_blogauthor == "true"){ ?>
<div class="comment-wrap" id="about-author-wrap">
  <div class="comment-content">
  	<div class="comment-gravatar"><?php echo get_avatar(get_the_author_email(),$size='80',$default=get_template_directory_uri().'/styles/_shared/gravatar.gif' ); ?>
  	</div><!-- end comment-gravatar -->
  
  	<div class="comment-text">
    <p class="comment-author-about">About the Author</p>
    <?php the_author_meta('description'); ?>
    </div><!-- end comment-text -->
    
  </div><!-- end comment-content -->
</div><!-- end comment-wrap -->
<?php } else {} ?>
</div><!-- end single_blog_wrap -->



<?php comments_template('', true); ?>
<?php endwhile; else: ?>
<h2>Nothing Found</h2>
<p>Sorry, it appears there is no content in this section.</p>
<?php endif; ?>
<?php if(function_exists('wp_pagenavi')) { wp_pagenavi(); } ?>
</div><!-- end content -->



<div id="sidebar" class="sidebar_blog">
<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar("Blog Sidebar") ) : ?><?php endif; ?>
</div><!-- end sidebar -->
</div><!-- end main-holder -->
</div><!-- main-area -->



<?php get_footer(); ?>