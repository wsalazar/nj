<?php get_header(); ?>
<?php
$ka_blogtitle = get_option('ka_blogtitle');
$ka_searchbar = get_option('ka_searchbar');
$ka_crumbs = get_option('ka_crumbs');
$ka_blogbutton = get_option('ka_blogbutton');
$ka_dragshare = get_option('ka_dragshare');
?>
<div class="main-area">
<div class="tools">
<div class="holder">
<div class="frame">
<?php $post = $posts[0]; // Hack. Set $post so that the_date() works. ?>
	<?php /* If this is a category archive */ if (is_category()) { ?>
	<h1>Archive for '<?php single_cat_title(); ?>'</h1>
	<?php /* If this is a tag archive */ } elseif( is_tag() ) { ?>
	<h1>Posts Tagged '<?php single_tag_title(); ?>'</h1>
	<?php /* If this is a daily archive */ } elseif (is_day()) { ?>
	<h1>Archive for <?php the_time('F jS, Y'); ?></h1>
	<?php /* If this is a monthly archive */ } elseif (is_month()) { ?>
	<h1>Archive for <?php the_time('F, Y'); ?></h1>
	<?php /* If this is a yearly archive */ } elseif (is_year()) { ?>
	<h1>Archive for <?php the_time('Y'); ?></h1>
	<?php /* If this is an author archive */ } elseif (is_author()) { ?>
	<h1>Author Archive</h1>
	<?php /* If this is a paged archive */ } elseif (isset($_GET['paged']) && !empty($_GET['paged'])) { ?>
	<h1>Blog Archives</h1>
	<?php } ?>
<?php if ($ka_searchbar == "true"){include (TEMPLATEPATH . '/functions/content/searchform.php');} else {} ?>
<?php if ($ka_crumbs == "true"){ $bc = new simple_breadcrumb;} else {} ?>
</div><!-- end frame -->
</div><!-- end holder -->
</div><!-- end tools -->



<div class="main-holder">			
<div id="content" class="content_blog">
<?php if (have_posts()) : while (have_posts()) : the_post(); 
$ka_post_thumb = wp_get_attachment_url(get_post_thumbnail_id( $post->ID ));
?>


<div class="blog_wrap">
<div class="post_title">
<h1><?php the_title(); ?></h1>
<p><span>Posted by:</span> <?php the_author_posts_link(); ?></p>
</div><!-- end post_title -->


<?php if (has_post_thumbnail()) : ?>
<div class="post_content">
<div class="post_thumb">
<div class="post_thumb_load">
<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>">
<?php echo '<img src="'.KARMA_FRAMEWORK.'/thumbs.php?src='.$ka_post_thumb.'&amp;h=218&amp;w=538&amp;zc=1" alt="#" />';?>
</a>
</div><!-- end post_thumb_load -->
</div><!-- end post_thumb -->
<?php else : ?> <div class="post_content">
<?php endif; ?>


<?php the_excerpt(); ?>
<a class="ka_button small_button" href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>"><span><?php echo $ka_blogbutton; ?></span></a>
<div class="post_date"><span class="day"><?php the_time('j'); ?></span><br /><span class="month"><?php echo strtoupper(get_the_time('M')); ?></span></div><!-- end post_date -->
<div class="post_comments"><span><?php comments_number('0', '1', '%'); ?></span></div><!-- end post_comments -->
<?php if ($ka_dragshare == "true"){ echo '<a class="post_share sharelink_small" href="#">Share</a>'; }?>
</div><!-- end post_content -->
<div class="post_footer">
<div class="post_cats">
	<p><span>Categories:</span> <?php the_category(', '); ?></p>
</div><!-- end post_cats -->
<?php if (get_the_tags()) : ?>
<div class="post_tags">
	<p><span>Tags:</span>  <?php the_tags('', ', '); ?></p>
</div><!-- end post_tags -->
<?php endif; ?>
</div><!-- end post_footer -->
</div><!-- end blog_wrap -->



<?php endwhile; else: ?>
<h2>Nothing Found</h1>
<p>Sorry, it appears there is no content in this section.</p>
<?php endif; ?>
<?php if(function_exists('wp_pagenavi')) { wp_pagenavi(); } ?>
</div><!-- end content -->



<div id="sidebar" class="sidebar_blog">
<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar("Blog Sidebar") ) : ?><?php endif; ?>
</div><!-- end sidebar -->
</div><!-- end main-holder -->
</div><!-- main-area -->



<?php get_footer(); ?>