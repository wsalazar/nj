function embedshortcode() {
	
	var shortcodetext;
	var style = document.getElementById('shortcode_panel');
	

	if (style.className.indexOf('current') != -1) {
		var selected_shortcode = document.getElementById('style_shortcode').value;
		
		
		
// -----------------------------
// 	LAYOUT SHORTCODES
// -----------------------------		
if (selected_shortcode == 'two_columns'){
	shortcodetext = "[one_half]<br />Content goes here...<br />[/one_half]<br /><br />[one_half_last]<br />Content goes here...<br />[/one_half_last]<br />";	
}

if (selected_shortcode == 'three_columns'){
	shortcodetext = "[one_third]<br />Content goes here...<br />[/one_third]<br /><br />[one_third]<br />Content goes here...<br />[/one_third]<br /><br />[one_third_last]<br />Content goes here...<br />[/one_third_last]<br />";	
}

if (selected_shortcode == 'four_columns'){
	shortcodetext = "[one_fourth]<br />Content goes here...<br />[/one_fourth]<br /><br />[one_fourth]<br />Content goes here...<br />[/one_fourth]<br /><br />[one_fourth]<br />Content goes here...<br />[/one_fourth]<br /><br />[one_fourth_last]<br />Content goes here...<br />[/one_fourth_last]<br />";	
}

if (selected_shortcode == 'five_columns'){
	shortcodetext = "[one_fifth]<br />Content goes here...<br />[/one_fifth]<br /><br />[one_fifth]<br />Content goes here...<br />[/one_fifth]<br /><br />[one_fifth]<br />Content goes here...<br />[/one_fifth]<br /><br />[one_fifth]<br />Content goes here...<br />[/one_fifth]<br /><br />[one_fifth_last]<br />Content goes here...<br />[/one_fifth_last]<br />";	
}

if (selected_shortcode == 'six_columns'){
	shortcodetext = "[one_sixth]<br />Content goes here...<br />[/one_sixth]<br /><br />[one_sixth]<br />Content goes here...<br />[/one_sixth]<br /><br />[one_sixth]<br />Content goes here...<br />[/one_sixth]<br /><br />[one_sixth]<br />Content goes here...<br />[/one_sixth]<br /><br />[one_sixth]<br />Content goes here...<br />[/one_sixth]<br /><br />[one_sixth_last]<br />Content goes here...<br />[/one_sixth_last]<br />";	
}

if (selected_shortcode == 'one_fourth_three_fourth_columns'){
	shortcodetext = "[one_fourth]<br />Content goes here...<br />[/one_fourth]<br /><br />[three_fourth_last]<br />Content goes here...<br />[/three_fourth_last]<br />";	
}

if (selected_shortcode == 'three_fourth_one_fourth_columns'){
	shortcodetext = "[three_fourth]<br />Content goes here...<br />[/three_fourth]<br /><br />[one_fourth_last]<br />Content goes here...<br />[/one_fourth_last]<br />";	
}

if (selected_shortcode == 'two_thirds_one_third_columns'){
	shortcodetext = "[two_thirds]<br />Content goes here...<br />[/two_thirds]<br /><br />[one_third_last]<br />Content goes here...<br />[/one_third_last]<br />";	
}

if (selected_shortcode == 'one_third_two_thirds_columns'){
	shortcodetext = "[one_third]<br />Content goes here...<br />[/one_third]<br /><br />[two_thirds_last]<br />Content goes here...<br />[/two_thirds_last]<br />";	
}











// -----------------------------
// 	LIST SHORTCODES
// -----------------------------
if (selected_shortcode == 'arrow_list'){
	shortcodetext = "[arrow_list]<li>Item 1...</li><li>Item 2...</li><li>Item 3...</li>[/arrow_list]<br />";	
}

if (selected_shortcode == 'star_list'){
	shortcodetext = "[star_list]<li>Item 1...</li><li>Item 2...</li><li>Item 3...</li>[/star_list]<br />";	
}

if (selected_shortcode == 'circle_list'){
	shortcodetext = "[circle_list]<li>Item 1...</li><li>Item 2...</li><li>Item 3...</li>[/circle_list]<br />";	
}

if (selected_shortcode == 'check_mark_list'){
	shortcodetext = "[check_list]<li>Item 1...</li><li>Item 2...</li><li>Item 3...</li>[/check_list]<br />";	
}
	







// -----------------------------
// 	INTERFACE SHORTCODES
// -----------------------------
if (selected_shortcode == 'accordion'){
	shortcodetext = "[accordion]<br />[slide name=\"title1\"]slide content 1[/slide]<br />[slide name=\"title2\"]slide content 2[/slide]<br />[slide name=\"title3\"]slide content 3[/slide]<br />[/accordion]<br />";	
}

if (selected_shortcode == 'tabs'){
	shortcodetext = "[tabset tab1=\"tab 1 title\" tab2=\"tab 2 title\"]<br />[tab]tab 1 content[/tab]<br /><br />[tab]tab 2 content[/tab]<br />[/tabset]<br />";	
}







// -----------------------------
// 	IMAGE FRAME SHORTCODES
// -----------------------------
if (selected_shortcode == 'modern_frame_banner_large'){
	shortcodetext = "[modernframe size=\"modern_banner_full\" image_path=\"http://www.\" description=\"\" link_to_page=\"http://www.\" ]<br />";	
}

if (selected_shortcode == 'modern_frame_banner_medium'){
	shortcodetext = "[modernframe size=\"modern_banner_regular\" image_path=\"http://www.\" description=\"\" link_to_page=\"http://www.\" ]<br />";	
}

if (selected_shortcode == 'modern_frame_banner_small'){
	shortcodetext = "[modernframe size=\"modern_banner_small\" image_path=\"http://www.\" description=\"\" link_to_page=\"http://www.\" ]<br />";	
}

if (selected_shortcode == 'modern_frame_2col'){
	shortcodetext = "[modernframe size=\"modern_two_col_large\" image_path=\"http://www.\" description=\"\" link_to_page=\"http://www.\" ]<br />";	
}

if (selected_shortcode == 'modern_frame_2col_small'){
	shortcodetext = "[modernframe size=\"modern_two_col_small\" image_path=\"http://www.\" description=\"\" link_to_page=\"http://www.\" ]<br />";	
}

if (selected_shortcode == 'modern_frame_3col'){
	shortcodetext = "[modernframe size=\"modern_three_col_large\" image_path=\"http://www.\" description=\"\" link_to_page=\"http://www.\" ]<br />";	
}

if (selected_shortcode == 'modern_frame_3col_small'){
	shortcodetext = "[modernframe size=\"modern_three_col_small\" image_path=\"http://www.\" description=\"\" link_to_page=\"http://www.\" ]<br />";	
}

if (selected_shortcode == 'modern_frame_4col'){
	shortcodetext = "[modernframe size=\"modern_four_col_large\" image_path=\"http://www.\" description=\"\" link_to_page=\"http://www.\" ]<br />";	
}

if (selected_shortcode == 'modern_frame_4col_small'){
	shortcodetext = "[modernframe size=\"modern_four_col_small\" image_path=\"http://www.\" description=\"\" link_to_page=\"http://www.\" ]<br />";	
}


if (selected_shortcode == 'shadow_frame_banner_large'){
	shortcodetext = "[shadowframe size=\"shadow_banner_full\" image_path=\"http://www.\" description=\"\" link_to_page=\"http://www.\" ]<br />";	
}

if (selected_shortcode == 'shadow_frame_banner_medium'){
	shortcodetext = "[shadowframe size=\"shadow_banner_regular\" image_path=\"http://www.\" description=\"\" link_to_page=\"http://www.\" ]<br />";	
}

if (selected_shortcode == 'shadow_frame_banner_small'){
	shortcodetext = "[shadowframe size=\"shadow_banner_small\" image_path=\"http://www.\" description=\"\" link_to_page=\"http://www.\" ]<br />";	
}

if (selected_shortcode == 'shadow_frame_2col'){
	shortcodetext = "[shadowframe size=\"shadow_two_col_large\" image_path=\"http://www.\" description=\"\" link_to_page=\"http://www.\" ]<br />";	
}

if (selected_shortcode == 'shadow_frame_2col_small'){
	shortcodetext = "[shadowframe size=\"shadow_two_col_small\" image_path=\"http://www.\" description=\"\" link_to_page=\"http://www.\" ]<br />";	
}

if (selected_shortcode == 'shadow_frame_3col'){
	shortcodetext = "[shadowframe size=\"shadow_three_col_large\" image_path=\"http://www.\" description=\"\" link_to_page=\"http://www.\" ]<br />";	
}

if (selected_shortcode == 'shadow_frame_3col_small'){
	shortcodetext = "[shadowframe size=\"shadow_three_col_small\" image_path=\"http://www.\" description=\"\" link_to_page=\"http://www.\" ]<br />";	
}

if (selected_shortcode == 'shadow_frame_4col'){
	shortcodetext = "[shadowframe size=\"shadow_four_col_large\" image_path=\"http://www.\" description=\"\" link_to_page=\"http://www.\" ]<br />";	
}

if (selected_shortcode == 'shadow_frame_4col_small'){
	shortcodetext = "[shadowframe size=\"shadow_four_col_small\" image_path=\"http://www.\" description=\"\" link_to_page=\"http://www.\" ]<br />";	
}














// -----------------------------
// 	DIVIDER SHORTCODES
// -----------------------------
if (selected_shortcode == 'basic_divider'){
	shortcodetext = "[hr]<br />";	
}

if (selected_shortcode == 'shadow_divider'){
	shortcodetext = "[hr_shadow]<br />";	
}

if (selected_shortcode == 'toplink_divider'){
	shortcodetext = "[top_link]text for link[/top_link]<br />";	
}







// -----------------------------
// 	BUTTON SHORTCODES
// -----------------------------
if (selected_shortcode == 'Autumn_button'){
	shortcodetext = "[button size=\"small,medium,large\" style=\"autumn\" url=\"http://www.\" ]Content goes here...[/button]<br />";	
}
if (selected_shortcode == 'Black_button'){
	shortcodetext = "[button size=\"small,medium,large\" style=\"black\" url=\"http://www.\" ]Content goes here...[/button]<br />";	
}
if (selected_shortcode == 'Cherry_button'){
	shortcodetext = "[button size=\"small,medium,large\" style=\"cherry\" url=\"http://www.\" ]Content goes here...[/button]<br />";	
}
if (selected_shortcode == 'Coffee_button'){
	shortcodetext = "[button size=\"small,medium,large\" style=\"coffee\" url=\"http://www.\" ]Content goes here...[/button]<br />";	
}
if (selected_shortcode == 'Fire_button'){
	shortcodetext = "[button size=\"small,medium,large\" style=\"fire\" url=\"http://www.\" ]Content goes here...[/button]<br />";	
}
if (selected_shortcode == 'Golden_button'){
	shortcodetext = "[button size=\"small,medium,large\" style=\"golden\" url=\"http://www.\" ]Content goes here...[/button]<br />";	
}
if (selected_shortcode == 'Pink_button'){
	shortcodetext = "[button size=\"small,medium,large\" style=\"pink\" url=\"http://www.\" ]Content goes here...[/button]<br />";	
}
if (selected_shortcode == 'Purple_button'){
	shortcodetext = "[button size=\"small,medium,large\" style=\"purple\" url=\"http://www.\" ]Content goes here...[/button]<br />";	
}
if (selected_shortcode == 'Periwinkle_button'){
	shortcodetext = "[button size=\"small,medium,large\" style=\"periwinkle\" url=\"http://www.\" ]Content goes here...[/button]<br />";	
}
if (selected_shortcode == 'Violet_button'){
	shortcodetext = "[button size=\"small,medium,large\" style=\"violet\" url=\"http://www.\" ]Content goes here...[/button]<br />";	
}
if (selected_shortcode == 'SkyBlue_button'){
	shortcodetext = "[button size=\"small,medium,large\" style=\"skyblue\" url=\"http://www.\" ]Content goes here...[/button]<br />";	
}
if (selected_shortcode == 'Grey_button'){
	shortcodetext = "[button size=\"small,medium,large\" style=\"grey\" url=\"http://www.\" ]Content goes here...[/button]<br />";	
}
if (selected_shortcode == 'Silver_button'){
	shortcodetext = "[button size=\"small,medium,large\" style=\"silver\" url=\"http://www.\" ]Content goes here...[/button]<br />";	
}
if (selected_shortcode == 'CoolBlue_button'){
	shortcodetext = "[button size=\"small,medium,large\" style=\"coolblue\" url=\"http://www.\" ]Content goes here...[/button]<br />";	
}
if (selected_shortcode == 'RoyalBlue_button'){
	shortcodetext = "[button size=\"small,medium,large\" style=\"royalblue\" url=\"http://www.\" ]Content goes here...[/button]<br />";	
}
if (selected_shortcode == 'BlueGrey_button'){
	shortcodetext = "[button size=\"small,medium,large\" style=\"bluegrey\" url=\"http://www.\" ]Content goes here...[/button]<br />";	
}
if (selected_shortcode == 'LimeGreen_button'){
	shortcodetext = "[button size=\"small,medium,large\" style=\"limegreen\" url=\"http://www.\" ]Content goes here...[/button]<br />";	
}
if (selected_shortcode == 'ForestGreen_button'){
	shortcodetext = "[button size=\"small,medium,large\" style=\"forestgreen\" url=\"http://www.\" ]Content goes here...[/button]<br />";	
}
if (selected_shortcode == 'Teal_button'){
	shortcodetext = "[button size=\"small,medium,large\" style=\"teal\" url=\"http://www.\" ]Content goes here...[/button]<br />";	
}
if (selected_shortcode == 'TealGrey_button'){
	shortcodetext = "[button size=\"small,medium,large\" style=\"tealgrey\" url=\"http://www.\" ]Content goes here...[/button]<br />";	
}







// -----------------------------
// 	TEXT STYLING SHORTCODES
// -----------------------------
if (selected_shortcode == 'text_callout1'){
	shortcodetext = "[callout1]Content goes here...[/callout1]<br />";	
}

if (selected_shortcode == 'text_callout2'){
	shortcodetext = "[callout2]Content goes here...[/callout2]<br />";	
}

if (selected_shortcode == 'text_h1'){
	shortcodetext = "[h1]Content goes here...[/h1]<br />";	
}

if (selected_shortcode == 'text_h2'){
	shortcodetext = "[h2]Content goes here...[/h2]<br />";	
}

if (selected_shortcode == 'text_h3'){
	shortcodetext = "[h3]Content goes here...[/h3]<br />";	
}

if (selected_shortcode == 'text_h4'){
	shortcodetext = "[h4]Content goes here...[/h4]<br />";	
}

if (selected_shortcode == 'text_h5'){
	shortcodetext = "[h5]Content goes here...[/h5]<br />";	
}

if (selected_shortcode == 'text_h6'){
	shortcodetext = "[h6]Content goes here...[/h6]<br />";	
}








// -----------------------------
// 	CALLOUT BOX SHORTCODES
// -----------------------------
if (selected_shortcode == 'callout_green'){
	shortcodetext = "[green_callout]Content goes here...[/green_callout]<br />";	
}

if (selected_shortcode == 'callout_blue'){
	shortcodetext = "[blue_callout]Content goes here...[/blue_callout]<br />";	
}

if (selected_shortcode == 'callout_red'){
	shortcodetext = "[red_callout]Content goes here...[/red_callout]<br />";	
}

if (selected_shortcode == 'callout_yellow'){
	shortcodetext = "[yellow_callout]Content goes here...[/yellow_callout]<br />";	
}









// -----------------------------
// 	PRE-BUILT LAYOUT SHORTCODES
// -----------------------------
if (selected_shortcode == 'layout_4_columns'){
	shortcodetext = "[callout1]Callout Content goes here...[/callout1]<br /><br />[one_fourth]<br />Content goes here...<br />[/one_fourth]<br /><br />[one_fourth]<br />Content goes here...<br />[/one_fourth]<br /><br />[one_fourth]<br />Content goes here...<br />[/one_fourth]<br /><br />[one_fourth_last]<br />Content goes here...<br />[/one_fourth_last]<br /><br />";	
}


if (selected_shortcode == 'layout_3_columns'){
	shortcodetext = "[callout1]Callout Content goes here...[/callout1]<br /><br />[one_third]<br />Content goes here...<br />[/one_third]<br /><br />[one_third]<br />Content goes here...<br />[/one_third]<br /><br />[one_third_last]<br />Content goes here...<br />[/one_third_last]<br /><br />";	
}


if (selected_shortcode == 'layout_video_left'){
	shortcodetext = "[video_left][video_frame]<br />[iframe url=\"URL to video here...\" width=\"572\" height=\"312\" scrolling=\"no\" frameborder=\"0\" marginheight=\"0\"]<br />[/video_frame]<br /><br />[video_text]<br />[h2]Title goes here...[/h2]<br />Content goes here...<br />[/video_text][/video_left]<br /><br />[callout1]Callout Content goes here...[/callout1]<br /><br />[one_fourth]<br />Content goes here...<br />[/one_fourth]<br /><br />[one_fourth]<br />Content goes here...<br />[/one_fourth]<br /><br />[one_fourth]<br />Content goes here...<br />[/one_fourth]<br /><br />[one_fourth_last]<br />Content goes here...<br />[/one_fourth_last]<br /><br />";	
}

if (selected_shortcode == 'layout_video_right'){
	shortcodetext = "[video_right][video_frame]<br />[iframe url=\"URL to video here...\" width=\"572\" height=\"312\" scrolling=\"no\" frameborder=\"0\" marginheight=\"0\"]<br />[/video_frame]<br /><br />[video_text]<br />[h2]Title goes here...[/h2]<br />Content goes here...<br />[/video_text][/video_right]<br /><br />[callout1]Callout Content goes here...[/callout1]<br /><br />[one_fourth]<br />Content goes here...<br />[/one_fourth]<br /><br />[one_fourth]<br />Content goes here...<br />[/one_fourth]<br /><br />[one_fourth]<br />Content goes here...<br />[/one_fourth]<br /><br />[one_fourth_last]<br />Content goes here...<br />[/one_fourth_last]<br /><br />";	
}

if (selected_shortcode == 'layout_slider_full'){
	shortcodetext = "...replace this line with CU3ER Slider shortcode...<br /><br />[callout1]Callout Content goes here...[/callout1]<br /><br />[one_fourth]<br />Content goes here...<br />[/one_fourth]<br /><br />[one_fourth]<br />Content goes here...<br />[/one_fourth]<br /><br />[one_fourth]<br />Content goes here...<br />[/one_fourth]<br /><br />[one_fourth_last]<br />Content goes here...<br />[/one_fourth_last]<br /><br />";	
}

if (selected_shortcode == 'layout_thumbnails_full'){
	shortcodetext = "...replace this line with CU3ER Thumbnails shortcode...<br /><br />[callout1]Callout Content goes here...[/callout1]<br /><br />[one_fourth]<br />Content goes here...<br />[/one_fourth]<br /><br />[one_fourth]<br />Content goes here...<br />[/one_fourth]<br /><br />[one_fourth]<br />Content goes here...<br />[/one_fourth]<br /><br />[one_fourth_last]<br />Content goes here...<br />[/one_fourth_last]<br /><br />";	
}

if (selected_shortcode == 'layout_thumbnails_left'){
	shortcodetext = "[3d_thumbs_left]<br />[3d_thumbs_frame]<br />CU3ER shortcode goes here...<br />[/3d_thumbs_frame]<br /><br />[3d_thumbs_text]<br />Content goes here...<br />[/3d_thumbs_text]<br />[/3d_thumbs_left]<br /><br />[callout1]Callout Content goes here...[/callout1]<br /><br />[one_fourth]<br />Content goes here...<br />[/one_fourth]<br /><br />[one_fourth]<br />Content goes here...<br />[/one_fourth]<br /><br />[one_fourth]<br />Content goes here...<br />[/one_fourth]<br /><br />[one_fourth_last]<br />Content goes here...<br />[/one_fourth_last]<br /><br />";	
}

if (selected_shortcode == 'layout_thumbnails_right'){
	shortcodetext = "[3d_thumbs_right]<br />[3d_thumbs_frame]<br />CU3ER shortcode goes here...<br />[/3d_thumbs_frame]<br /><br />[3d_thumbs_text]<br />Content goes here...<br />[/3d_thumbs_text]<br />[/3d_thumbs_right]<br /><br />[callout1]Callout Content goes here...[/callout1]<br /><br />[one_fourth]<br />Content goes here...<br />[/one_fourth]<br /><br />[one_fourth]<br />Content goes here...<br />[/one_fourth]<br /><br />[one_fourth]<br />Content goes here...<br />[/one_fourth]<br /><br />[one_fourth_last]<br />Content goes here...<br />[/one_fourth_last]<br /><br />";	
}






// -----------------------------
// 	LAYOUT ELEMENTS SHORTCODES
// -----------------------------
if (selected_shortcode == 'elements_video_left'){
	shortcodetext = "[video_left][video_frame]<br />[iframe url=\"URL to video here...\" width=\"572\" height=\"312\" scrolling=\"no\" frameborder=\"0\" marginheight=\"0\"]<br />[/video_frame]<br /><br />[video_text]<br />[h2]Title goes here...[/h2]<br />Content goes here...<br />[/video_text][/video_left]<br />";	
}

if (selected_shortcode == 'elements_video_right'){
	shortcodetext = "[video_right][video_frame]<br />[iframe url=\"URL to video here...\" width=\"572\" height=\"312\" scrolling=\"no\" frameborder=\"0\" marginheight=\"0\"]<br />[/video_frame]<br /><br />[video_text]<br />[h2]Title goes here...[/h2]<br />Content goes here...<br />[/video_text][/video_right]<br />";	
}

if (selected_shortcode == 'elements_flash_slider_wrap'){
	shortcodetext = "[flash_wrap]<br />Flash slider goes here...<br />[/flash_wrap]<br />";	
}

if (selected_shortcode == 'elements_thumbnails_left'){
	shortcodetext = "[3d_thumbs_left]<br />[3d_thumbs_frame]<br />CU3ER shortcode goes here...<br />[/3d_thumbs_frame]<br /><br />[3d_thumbs_text]<br />Content goes here...<br />[/3d_thumbs_text]<br />[/3d_thumbs_left]<br />";	
}

if (selected_shortcode == 'elements_thumbnails_right'){
	shortcodetext = "[3d_thumbs_right]<br />[3d_thumbs_frame]<br />CU3ER shortcode goes here...<br />[/3d_thumbs_frame]<br /><br />[3d_thumbs_text]<br />Content goes here...<br />[/3d_thumbs_text]<br />[/3d_thumbs_right]<br />";	
}














// -----------------------------
// 	MISC SHORTCODES
// -----------------------------
if (selected_shortcode == 'testimonials'){
	shortcodetext = "[testimonial_wrap]<br />[testimonial]Content goes here...[client_name]John Doe, Company Name[/client_name][/testimonial]<br />[testimonial]Content goes here...[client_name]John Doe, Company Name[/client_name][/testimonial]<br />[testimonial]Content goes here...[client_name]John Doe, Company Name[/client_name][/testimonial]<br />[/testimonial_wrap]<br />";	
}

if (selected_shortcode == 'related_posts'){
	shortcodetext = "[related_posts limit=\"5\" title=\"Related Posts\"]<br />";	
}

if (selected_shortcode == 'latest_tweets'){
	shortcodetext = "[latest_tweets user=\"your_user_name_here\" num=\"3\"]<br />";	
}



		
		
		
		
		
		
		

	if ( selected_shortcode == 0 ){tinyMCEPopup.close();}}
	if(window.tinyMCE) {
		window.tinyMCE.execInstanceCommand('content', 'mceInsertContent', false, shortcodetext);
		tinyMCEPopup.editor.execCommand('mceRepaint');
		tinyMCEPopup.close();
	}return;
}