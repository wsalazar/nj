<?php require_once('config.php');
if ( !is_user_logged_in() || !current_user_can('edit_posts') ) wp_die(__("You are not allowed to be here")); ?>

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Shortcodes</title>
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php echo get_option('blog_charset'); ?>" />
<script language="javascript" type="text/javascript" src="<?php echo get_template_directory_uri() ?>/functions/extended/wysiwyg/wysiwyg.js"></script>
<script language="javascript" type="text/javascript" src="<?php echo get_option('siteurl') ?>/wp-includes/js/tinymce/tiny_mce_popup.js"></script>
<base target="_self" />
</head>
<body onLoad="tinyMCEPopup.executeOnLoad('init();');document.body.style.display='';" style="display: none" id="link">
<form name="karma_shortcode_form" action="#">

	
<div style="height:100px;width:250px;margin:0 auto;padding-top:50px;text-align:center;" class="shortcode_wrap">
<div id="shortcode_panel" class="current" style="height:50px;">
<fieldset style="border:0;width:100%;text-align:center;">
<select id="style_shortcode" name="style_shortcode" style="width:250px">
<option value="0">Select a Shortcode...</option>
<option value="0" style="font-weight:bold;font-style:italic;">Column Shortcodes</option>
     <option value="two_columns">2 Columns</option>
     <option value="three_columns">3 Columns</option>
     <option value="four_columns">4 Columns</option>
     <option value="five_columns">5 Columns</option>
     <option value="six_columns">6 Columns</option>
     <option value="one_fourth_three_fourth_columns">1/4 Column + 3/4 Column</option>
     <option value="three_fourth_one_fourth_columns">3/4 Column + 1/4 Column</option>
     <option value="two_thirds_one_third_columns">2/3 Column + 1/3 Column</option>
     <option value="one_third_two_thirds_columns">1/3 Column + 2/3 Column</option>
     
<option value="0"> </option>  
<option value="0" style="font-weight:bold;font-style:italic;">Layout Elements</option>
     <option value="elements_video_left">Video (left)</option>
     <option value="elements_video_right">Video (right)</option>
     <option value="elements_flash_slider_wrap">Flash Slider Wrap</option>
     

<option value="0"> </option>  
<option value="0" style="font-weight:bold;font-style:italic;">Ready-Made Layouts</option>
     <option value="layout_4_columns">Homepage - 4 Columns</option>
     <option value="layout_3_columns">Homepage - 3 Columns</option>
     <option value="layout_video_left">Homepage - Video (left)</option>
     <option value="layout_video_right">Homepage - Video (right)</option>
     
<option value="0"> </option>
<option value="0" style="font-weight:bold;font-style:italic;">Interface Shortcodes</option>
     <option value="accordion">Accordion</option>
     <option value="tabs">Tabs</option>
     
<option value="0"> </option>
<option value="0" style="font-weight:bold;font-style:italic;">Text Styling</option>
     <option value="text_callout1">Callout Text 1</option>
     <option value="text_callout2">Callout Text 2</option>
     <option value="text_h1">Heading 1 (H1)</option> 
     <option value="text_h2">Heading 2 (H2)</option> 
     <option value="text_h3">Heading 3 (H3)</option> 
     <option value="text_h4">Heading 4 (H4)</option> 
     <option value="text_h5">Heading 5 (H5)</option> 
     <option value="text_h6">Heading 6 (H6)</option>
     
<option value="0"> </option>
<option value="0" style="font-weight:bold;font-style:italic;">Lists</option>
     <option value="arrow_list">Arrow List</option>
     <option value="star_list">Star List</option>
     <option value="circle_list">Circle List</option>
     <option value="check_mark_list">Check Mark List</option>
     
<option value="0"> </option>
<option value="0" style="font-weight:bold;font-style:italic;">Buttons</option>
     <option value="Autumn_button">Autumn</option>
     <option value="Black_button">Black</option>
     <option value="BlueGrey_button">Blue Grey</option>
     <option value="Cherry_button">Cherry</option>
     <option value="CoolBlue_button">Cool Blue</option>
     <option value="Coffee_button">Coffee</option>
     <option value="ForestGreen_button">Forest Green</option>
     <option value="Fire_button">Fire</option>
     <option value="Golden_button">Golden</option>
     <option value="Grey_button">Grey</option>
     <option value="LimeGreen_button">Lime Green</option>
     <option value="Periwinkle_button">Periwinkle</option>
     <option value="Pink_button">Pink</option>
     <option value="Purple_button">Purple</option>
     <option value="RoyalBlue_button">Royal Blue</option>
     <option value="SkyBlue_button">Sky Blue</option>
     <option value="Silver_button">Silver</option>
     <option value="Teal_button">Teal</option>
     <option value="TealGrey_button">Teal Grey</option>
     <option value="Violet_button">Violet</option>
     
     
     
<option value="0"> </option>
<option value="0" style="font-weight:bold;font-style:italic;">Dividers</option>
     <option value="basic_divider">Basic Divider</option> 
     <option value="shadow_divider">Shadow Divider</option>
     <option value="toplink_divider">Basic Divider + Top Link</option>
 
<option value="0"> </option>
<option value="0" style="font-weight:bold;font-style:italic;">Image Frames</option>
     <option value="modern_frame_banner_large">Modern Style - (large banner)</option>
     <option value="modern_frame_banner_medium">Modern Style - (medium banner)</option>
     <option value="modern_frame_banner_small">Modern Style - (small banner)</option>
     <option value="modern_frame_2col">Modern Style - (2 columns)</option>
     <option value="modern_frame_2col_small">Modern Style - (2 columns small)</option>
     <option value="modern_frame_3col">Modern Style - (3 columns)</option>
     <option value="modern_frame_3col_small">Modern Style - (3 columns small)</option>
     <option value="modern_frame_4col">Modern Style - (4 columns)</option>
     <option value="modern_frame_4col_small">Modern Style - (4 columns small)</option>
     <option value="shadow_frame_banner_large">Shadow Style - (large banner)</option>
     <option value="shadow_frame_banner_medium">Shadow Style - (medium banner)</option>
     <option value="shadow_frame_banner_small">Shadow Style - (small banner)</option>
     <option value="shadow_frame_2col">Shadow Style - (2 columns)</option>
     <option value="shadow_frame_2col_small">Shadow Style - (2 columns small)</option>
     <option value="shadow_frame_3col">Shadow Style - (3 columns)</option>
     <option value="shadow_frame_3col_small">Shadow Style - (3 columns small)</option>
     <option value="shadow_frame_4col">Shadow Style - (4 columns)</option>
     <option value="shadow_frame_4col_small">Shadow Style - (4 columns small)</option>
     
<option value="0"> </option>
<option value="0" style="font-weight:bold;font-style:italic;">Callout Boxes</option>
     <option value="callout_green">Green Callout Box</option>
     <option value="callout_blue">Blue Callout Box</option>
     <option value="callout_red">Red Callout Box</option>
     <option value="callout_yellow">Yellow Callout Box</option>
     
<option value="0"> </option>
<option value="0" style="font-weight:bold;font-style:italic;">Other Shortcodes</option>
     <option value="testimonials">Testimonials</option>
     <option value="related_posts">Related Posts</option>
     <option value="latest_tweets">Latest Tweets</option> 
  


</select>
</fieldset>
</div><!-- end shortcode_panel -->

<div style="float:left"><input type="button" id="cancel" name="cancel" value="<?php echo "Close"; ?>" onClick="tinyMCEPopup.close();" /></div>
<div style="float:right"><input type="submit" id="insert" name="insert" value="<?php echo "Insert"; ?>" onClick="embedshortcode();" /></div>

</div><!-- end shortcode_wrap -->




</form>
</body>
</html>
