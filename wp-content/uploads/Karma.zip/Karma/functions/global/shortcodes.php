<?php 
/* ----- UNFORMATTED TEXT ----- */
function my_formatter($content) {
	$new_content = '';
	$pattern_full = '{(\[raw\].*?\[/raw\])}is';
	$pattern_contents = '{\[raw\](.*?)\[/raw\]}is';
	$pieces = preg_split($pattern_full, $content, -1, PREG_SPLIT_DELIM_CAPTURE);

	foreach ($pieces as $piece) {
		if (preg_match($pattern_contents, $piece, $matches)) {
			$new_content .= $matches[1];
		} else {
			$new_content .= wptexturize(wpautop($piece));
		}
	}

	return $new_content;
}

remove_filter('the_content', 'wpautop');
remove_filter('the_content', 'wptexturize');
add_filter('the_content', 'my_formatter', 99);




/* ----- BASIC ----- */
function karma_h1( $atts, $content = null ) {
   return '<h1>' . do_shortcode($content) . '</h1>';
} add_shortcode('h1', 'karma_h1');

function karma_h2( $atts, $content = null ) {
   return '<h2>' . do_shortcode($content) . '</h2>';
} add_shortcode('h2', 'karma_h2');

function karma_h3( $atts, $content = null ) {
   return '<h3>' . do_shortcode($content) . '</h3>';
} add_shortcode('h3', 'karma_h3');

function karma_h4( $atts, $content = null ) {
   return '<h4>' . do_shortcode($content) . '</h4>';
} add_shortcode('h4', 'karma_h4');

function karma_h5( $atts, $content = null ) {
   return '<h5>' . do_shortcode($content) . '</h5>';
} add_shortcode('h5', 'karma_h5');

function karma_h6( $atts, $content = null ) {
   return '<h6>' . do_shortcode($content) . '</h6>';
} add_shortcode('h6', 'karma_h6');











/* ----- SHADOW IMAGE FRAME ----- */
function karma_shadow_frame($atts, $content = null) {
  extract(shortcode_atts(array(
  'size' => '',
  'image_path' => '',
  'description' => '',
  'link_to_page' => '',
  // 'target' => '',
  ), $atts));
  
 
 /* fullsize banner */ 
 if ($size == 'shadow_banner_full' && $link_to_page != ''){
		  $output = '[raw]<div class="shadow_img_frame '.$size.'"><div class="shadow_preload_full"><div class="attachment-fadeIn">
  <a href="'.$link_to_page.'"><img src="'.KARMA_FRAMEWORK.'/thumbs.php?src='.$image_path.'&amp;h=208&amp;w=928&amp;zc=1" alt="'.$description.'" /></a></div></div>
</div><!-- end shadow_img_frame -->[/raw]';
		  }
		  
		  elseif ($size == 'shadow_banner_full' && $link_to_page == ''){
		  $output = '[raw]<div class="shadow_img_frame '.$size.'"><div class="shadow_preload_full"><div class="attachment-fadeIn">
 <img src="'.KARMA_FRAMEWORK.'/thumbs.php?src='.$image_path.'&amp;h=208&amp;w=928&amp;zc=1" alt="'.$description.'" /></div></div>
</div><!-- end shadow_img_frame -->[/raw]';
		  }
		  
 /* regular banner */ 
 if ($size == 'shadow_banner_regular' && $link_to_page != ''){
		  $output = '[raw]<div class="shadow_img_frame '.$size.'"><div class="shadow_preload_regular"><div class="attachment-fadeIn">
  <a href="'.$link_to_page.'"><img src="'.KARMA_FRAMEWORK.'/thumbs.php?src='.$image_path.'&amp;h=208&amp;w=708&amp;zc=1" alt="'.$description.'" /></a></div></div>
</div><!-- end shadow_img_frame -->[/raw]';
		  }
		  
		  elseif ($size == 'shadow_banner_regular' && $link_to_page == ''){
		  $output = '[raw]<div class="shadow_img_frame '.$size.'"><div class="shadow_preload_regular"><div class="attachment-fadeIn">
 <img src="'.KARMA_FRAMEWORK.'/thumbs.php?src='.$image_path.'&amp;h=208&amp;w=708&amp;zc=1" alt="'.$description.'" /></div></div>
</div><!-- end shadow_img_frame -->[/raw]';
		  }  
		  
 /* half banner */ 
 if ($size == 'shadow_banner_small' && $link_to_page != ''){
		  $output = '[raw]<div class="shadow_img_frame '.$size.'"><div class="shadow_preload_small"><div class="attachment-fadeIn">
  <a href="'.$link_to_page.'"><img src="'.KARMA_FRAMEWORK.'/thumbs.php?src='.$image_path.'&amp;h=208&amp;w=498&amp;zc=1" alt="'.$description.'" /></a></div></div>
</div><!-- end shadow_img_frame -->[/raw]';
		  }
		  
		  elseif ($size == 'shadow_banner_small' && $link_to_page == ''){
		  $output = '[raw]<div class="shadow_img_frame '.$size.'"><div class="shadow_preload_small"><div class="attachment-fadeIn">
 <img src="'.KARMA_FRAMEWORK.'/thumbs.php?src='.$image_path.'&amp;h=208&amp;w=498&amp;zc=1" alt="'.$description.'" /></div></div>
</div><!-- end shadow_img_frame -->[/raw]';
		  }	  
		  
 /* two_col_large */ 
  elseif ($size == 'shadow_two_col_large' && $link_to_page != ''){
  $output = '[raw]<div class="shadow_img_frame '.$size.'"><div class="shadow_preload_two_col_large"><div class="attachment-fadeIn">
  <a href="'.$link_to_page.'"><img src="'.KARMA_FRAMEWORK.'/thumbs.php?src='.$image_path.'&amp;h=241&amp;w=443&amp;zc=1" alt="'.$description.'" /></a></div></div>
</div><!-- end shadow_img_frame -->[/raw]';
  }
  
  elseif ($size == 'shadow_two_col_large' && $link_to_page == ''){
  $output = '[raw]<div class="shadow_img_frame '.$size.'"><div class="shadow_preload_two_col_large"><div class="attachment-fadeIn">
  <img src="'.KARMA_FRAMEWORK.'/thumbs.php?src='.$image_path.'&amp;h=241&amp;w=443&amp;zc=1" alt="'.$description.'" /></div></div>
</div><!-- end shadow_img_frame -->[/raw]';
  }
  
   /* two_col_small */ 
  elseif ($size == 'shadow_two_col_small' && $link_to_page != ''){
  $output = '[raw]<div class="shadow_img_frame '.$size.'"><div class="shadow_preload_two_col_small"><div class="attachment-fadeIn">
  <a href="'.$link_to_page.'"><img src="'.KARMA_FRAMEWORK.'/thumbs.php?src='.$image_path.'&amp;h=186&amp;w=330&amp;zc=1" alt="'.$description.'" /></a></div></div>
</div><!-- end shadow_img_frame -->[/raw]';
	  }
	  
  elseif ($size == 'shadow_two_col_small' && $link_to_page == ''){
  $output = '[raw]<div class="shadow_img_frame '.$size.'"><div class="shadow_preload_two_col_small"><div class="attachment-fadeIn">
  <img src="'.KARMA_FRAMEWORK.'/thumbs.php?src='.$image_path.'&amp;h=186&amp;w=330&amp;zc=1" alt="'.$description.'" /></div></div>
</div><!-- end shadow_img_frame -->[/raw]';
	  }
	  
	  
	  /* three_col_large */ 
  elseif ($size == 'shadow_three_col_large' && $link_to_page != ''){
  $output = '[raw]<div class="shadow_img_frame '.$size.'"><div class="shadow_preload_three_col_large"><div class="attachment-fadeIn">
  <a href="'.$link_to_page.'"><img src="'.KARMA_FRAMEWORK.'/thumbs.php?src='.$image_path.'&amp;h=152&amp;w=281&amp;zc=1" alt="'.$description.'" /></a></div></div>
</div><!-- end shadow_img_frame -->[/raw]';
	  }
	  
  elseif ($size == 'shadow_three_col_large' && $link_to_page == ''){
  $output = '[raw]<div class="shadow_img_frame '.$size.'"><div class="shadow_preload_three_col_large"><div class="attachment-fadeIn">
  <img src="'.KARMA_FRAMEWORK.'/thumbs.php?src='.$image_path.'&amp;h=152&amp;w=281&amp;zc=1" alt="'.$description.'" /></div></div>
</div><!-- end shadow_img_frame -->[/raw]';
	  }
	  
	  
	   /* three_col_small */ 
  elseif ($size == 'shadow_three_col_small' && $link_to_page != ''){
  $output = '[raw]<div class="shadow_img_frame '.$size.'"><div class="shadow_preload_three_col_small"><div class="attachment-fadeIn">
  <a href="'.$link_to_page.'"><img src="'.KARMA_FRAMEWORK.'/thumbs.php?src='.$image_path.'&amp;h=120&amp;w=208&amp;zc=1" alt="'.$description.'" /></a></div></div>
</div><!-- end shadow_img_frame -->[/raw]';
	  }
	  
  elseif ($size == 'shadow_three_col_small' && $link_to_page == ''){
  $output = '[raw]<div class="shadow_img_frame '.$size.'"><div class="shadow_preload_three_col_small"><div class="attachment-fadeIn">
  <img src="'.KARMA_FRAMEWORK.'/thumbs.php?src='.$image_path.'&amp;h=120&amp;w=208&amp;zc=1" alt="'.$description.'" /></div></div>
</div><!-- end shadow_img_frame -->[/raw]';
	  }


	  /* four_col_large */
	  elseif ($size == 'shadow_four_col_large' && $link_to_page != ''){
		  $output = '[raw]<div class="shadow_img_frame '.$size.'"><div class="shadow_preload_four_col_large"><div class="attachment-fadeIn">
  <a href="'.$link_to_page.'"><img src="'.KARMA_FRAMEWORK.'/thumbs.php?src='.$image_path.'&amp;h=118&amp;w=196&amp;zc=1" alt="'.$description.'" /></a></div></div>
</div><!-- end shadow_img_frame -->[/raw]';
		  }
		  
		  elseif ($size == 'shadow_four_col_large' && $link_to_page == ''){
		  $output = '[raw]<div class="shadow_img_frame '.$size.'"><div class="shadow_preload_four_col_large"><div class="attachment-fadeIn">
 <img src="'.KARMA_FRAMEWORK.'/thumbs.php?src='.$image_path.'&amp;h=118&amp;w=196&amp;zc=1" alt="'.$description.'" /></div></div>
</div><!-- end shadow_img_frame -->[/raw]';
		  }
		  
		  
		  
		  /* four_col_small */
	  elseif ($size == 'shadow_four_col_small' && $link_to_page != ''){
		  $output = '[raw]<div class="shadow_img_frame '.$size.'"><div class="shadow_preload_four_col_small"><div class="attachment-fadeIn">
  <a href="'.$link_to_page.'"><img src="'.KARMA_FRAMEWORK.'/thumbs.php?src='.$image_path.'&amp;h=83&amp;w=140&amp;zc=1" alt="'.$description.'" /></a></div></div>
</div><!-- end shadow_img_frame -->[/raw]';
		  }
		  
		  elseif ($size == 'shadow_four_col_small' && $link_to_page == ''){
		  $output = '[raw]<div class="shadow_img_frame '.$size.'"><div class="shadow_preload_four_col_small"><div class="attachment-fadeIn">
 <img src="'.KARMA_FRAMEWORK.'/thumbs.php?src='.$image_path.'&amp;h=83&amp;w=140&amp;zc=1" alt="'.$description.'" /></div></div>
</div><!-- end shadow_img_frame -->[/raw]';
		  }
		  		  

  return $output;
}
add_shortcode('shadowframe', 'karma_shadow_frame');


















/* ----- MODERN IMAGE FRAME ----- */
function karma_modern_frame($atts, $content = null) {
  extract(shortcode_atts(array(
  'size' => '',
  'image_path' => '',
  'description' => '',
  'link_to_page' => '',
  // 'target' => '',
  ), $atts));
  
 
 /* fullsize banner */ 
 if ($size == 'modern_banner_full' && $link_to_page != ''){
		  $output = '[raw]<div class="modern_img_frame '.$size.'"><div class="preload_full"><div class="attachment-fadeIn">
  <a href="'.$link_to_page.'"><img src="'.KARMA_FRAMEWORK.'/thumbs.php?src='.$image_path.'&amp;h=201&amp;w=922&amp;zc=1" alt="'.$description.'" /></a></div></div>
</div><!-- end modern_img_frame -->[/raw]';
		  }
		  
		  elseif ($size == 'modern_banner_full' && $link_to_page == ''){
		  $output = '[raw]<div class="modern_img_frame '.$size.'"><div class="preload_full"><div class="attachment-fadeIn">
 <img src="'.KARMA_FRAMEWORK.'/thumbs.php?src='.$image_path.'&amp;h=201&amp;w=922&amp;zc=1" alt="'.$description.'" /></div></div>
</div><!-- end modern_img_frame -->[/raw]';
		  }
		  
 /* regular banner */ 
 if ($size == 'modern_banner_regular' && $link_to_page != ''){
		  $output = '[raw]<div class="modern_img_frame '.$size.'"><div class="preload_regular"><div class="attachment-fadeIn">
  <a href="'.$link_to_page.'"><img src="'.KARMA_FRAMEWORK.'/thumbs.php?src='.$image_path.'&amp;h=201&amp;w=703&amp;zc=1" alt="'.$description.'" /></a></div></div>
</div><!-- end modern_img_frame -->[/raw]';
		  }
		  
		  elseif ($size == 'modern_banner_regular' && $link_to_page == ''){
		  $output = '[raw]<div class="modern_img_frame '.$size.'"><div class="preload_regular"><div class="attachment-fadeIn">
 <img src="'.KARMA_FRAMEWORK.'/thumbs.php?src='.$image_path.'&amp;h=201&amp;w=703&amp;zc=1" alt="'.$description.'" /></div></div>
</div><!-- end modern_img_frame -->[/raw]';
		  }  
		  
 /* half banner */ 
 if ($size == 'modern_banner_small' && $link_to_page != ''){
		  $output = '[raw]<div class="modern_img_frame '.$size.'"><div class="preload_small"><div class="attachment-fadeIn">
  <a href="'.$link_to_page.'"><img src="'.KARMA_FRAMEWORK.'/thumbs.php?src='.$image_path.'&amp;h=201&amp;w=493&amp;zc=1" alt="'.$description.'" /></a></div></div>
</div><!-- end modern_img_frame -->[/raw]';
		  }
		  
		  elseif ($size == 'modern_banner_small' && $link_to_page == ''){
		  $output = '[raw]<div class="modern_img_frame '.$size.'"><div class="preload_small"><div class="attachment-fadeIn">
 <img src="'.KARMA_FRAMEWORK.'/thumbs.php?src='.$image_path.'&amp;h=201&amp;w=493&amp;zc=1" alt="'.$description.'" /></div></div>
</div><!-- end modern_img_frame -->[/raw]';
		  }	  
		  
 /* two_col_large */ 
  elseif ($size == 'modern_two_col_large' && $link_to_page != ''){
  $output = '[raw]<div class="modern_img_frame '.$size.'"><div class="preload_two_col_large"><div class="attachment-fadeIn">
  <a href="'.$link_to_page.'"><img src="'.KARMA_FRAMEWORK.'/thumbs.php?src='.$image_path.'&amp;h=234&amp;w=437&amp;zc=1" alt="'.$description.'" /></a></div></div>
</div><!-- end modern_img_frame -->[/raw]';
  }
  
  elseif ($size == 'modern_two_col_large' && $link_to_page == ''){
  $output = '[raw]<div class="modern_img_frame '.$size.'"><div class="preload_two_col_large"><div class="attachment-fadeIn">
  <img src="'.KARMA_FRAMEWORK.'/thumbs.php?src='.$image_path.'&amp;h=234&amp;w=437&amp;zc=1" alt="'.$description.'" /></div></div>
</div><!-- end modern_img_frame -->[/raw]';
  }
  
   /* two_col_small */ 
  elseif ($size == 'modern_two_col_small' && $link_to_page != ''){
  $output = '[raw]<div class="modern_img_frame '.$size.'"><div class="preload_two_col_small"><div class="attachment-fadeIn">
  <a href="'.$link_to_page.'"><img src="'.KARMA_FRAMEWORK.'/thumbs.php?src='.$image_path.'&amp;h=180&amp;w=324&amp;zc=1" alt="'.$description.'" /></a></div></div>
</div><!-- end modern_img_frame -->[/raw]';
	  }
	  
  elseif ($size == 'modern_two_col_small' && $link_to_page == ''){
  $output = '[raw]<div class="modern_img_frame '.$size.'"><div class="preload_two_col_small"><div class="attachment-fadeIn">
  <img src="'.KARMA_FRAMEWORK.'/thumbs.php?src='.$image_path.'&amp;h=180&amp;w=324&amp;zc=1" alt="'.$description.'" /></div></div>
</div><!-- end modern_img_frame -->[/raw]';
	  }
	  
	  
	  /* three_col_large */ 
  elseif ($size == 'modern_three_col_large' && $link_to_page != ''){
  $output = '[raw]<div class="modern_img_frame '.$size.'"><div class="preload_three_col_large"><div class="attachment-fadeIn">
  <a href="'.$link_to_page.'"><img src="'.KARMA_FRAMEWORK.'/thumbs.php?src='.$image_path.'&amp;h=145&amp;w=275&amp;zc=1" alt="'.$description.'" /></a></div></div>
</div><!-- end modern_img_frame -->[/raw]';
	  }
	  
  elseif ($size == 'modern_three_col_large' && $link_to_page == ''){
  $output = '[raw]<div class="modern_img_frame '.$size.'"><div class="preload_three_col_large"><div class="attachment-fadeIn">
  <img src="'.KARMA_FRAMEWORK.'/thumbs.php?src='.$image_path.'&amp;h=145&amp;w=275&amp;zc=1" alt="'.$description.'" /></div></div>
</div><!-- end modern_img_frame -->[/raw]';
	  }
	  
	  
	   /* three_col_small */ 
  elseif ($size == 'modern_three_col_small' && $link_to_page != ''){
  $output = '[raw]<div class="modern_img_frame '.$size.'"><div class="preload_three_col_small"><div class="attachment-fadeIn">
  <a href="'.$link_to_page.'"><img src="'.KARMA_FRAMEWORK.'/thumbs.php?src='.$image_path.'&amp;h=113&amp;w=202&amp;zc=1" alt="'.$description.'" /></a></div></div>
</div><!-- end modern_img_frame -->[/raw]';
	  }
	  
  elseif ($size == 'modern_three_col_small' && $link_to_page == ''){
  $output = '[raw]<div class="modern_img_frame '.$size.'"><div class="preload_three_col_small"><div class="attachment-fadeIn">
  <img src="'.KARMA_FRAMEWORK.'/thumbs.php?src='.$image_path.'&amp;h=113&amp;w=202&amp;zc=1" alt="'.$description.'" /></div></div>
</div><!-- end modern_img_frame -->[/raw]';
	  }


	  /* four_col_large */
	  elseif ($size == 'modern_four_col_large' && $link_to_page != ''){
		  $output = '[raw]<div class="modern_img_frame '.$size.'"><div class="preload_four_col_large"><div class="attachment-fadeIn">
  <a href="'.$link_to_page.'"><img src="'.KARMA_FRAMEWORK.'/thumbs.php?src='.$image_path.'&amp;h=111&amp;w=190&amp;zc=1" alt="'.$description.'" /></a></div></div>
</div><!-- end modern_img_frame -->[/raw]';
		  }
		  
		  elseif ($size == 'modern_four_col_large' && $link_to_page == ''){
		  $output = '[raw]<div class="modern_img_frame '.$size.'"><div class="preload_four_col_large"><div class="attachment-fadeIn">
 <img src="'.KARMA_FRAMEWORK.'/thumbs.php?src='.$image_path.'&amp;h=111&amp;w=190&amp;zc=1" alt="'.$description.'" /></div></div>
</div><!-- end modern_img_frame -->[/raw]';
		  }
		  
		  
		  
		  /* four_col_small */
	  elseif ($size == 'modern_four_col_small' && $link_to_page != ''){
		  $output = '[raw]<div class="modern_img_frame '.$size.'"><div class="preload_four_col_small"><div class="attachment-fadeIn">
  <a href="'.$link_to_page.'"><img src="'.KARMA_FRAMEWORK.'/thumbs.php?src='.$image_path.'&amp;h=76&amp;w=135&amp;zc=1" alt="'.$description.'" /></a></div></div>
</div><!-- end modern_img_frame -->[/raw]';
		  }
		  
		  elseif ($size == 'modern_four_col_small' && $link_to_page == ''){
		  $output = '[raw]<div class="modern_img_frame '.$size.'"><div class="preload_four_col_small"><div class="attachment-fadeIn">
 <img src="'.KARMA_FRAMEWORK.'/thumbs.php?src='.$image_path.'&amp;h=76&amp;w=135&amp;zc=1" alt="'.$description.'" /></div></div>
</div><!-- end modern_img_frame -->[/raw]';
		  }
		  		  

  return $output;
}
add_shortcode('modernframe', 'karma_modern_frame');

	

















/* ----- COLUMN LAYOUTS ----- */

/* 6 */
function karma_one_sixth( $atts, $content = null ) {
   return '[raw]<div class="one_sixth">[/raw]' . do_shortcode($content) . '[raw]</div>[/raw]';
}
add_shortcode('one_sixth', 'karma_one_sixth');


function karma_one_sixth_last( $atts, $content = null ) {
   return '[raw]<div class="one_sixth_last">[/raw]' . do_shortcode($content) . '[raw]</div><br class="clear" />[/raw]';
}
add_shortcode('one_sixth_last', 'karma_one_sixth_last');





/* 5 */
function karma_one_fifth( $atts, $content = null ) {
   return '[raw]<div class="one_fifth">[/raw]' . do_shortcode($content) . '[raw]</div>[/raw]';
}
add_shortcode('one_fifth', 'karma_one_fifth');


function karma_one_fifth_last( $atts, $content = null ) {
   return '[raw]<div class="one_fifth_last">[/raw]' . do_shortcode($content) . '[raw]</div><br class="clear" />[/raw]';
}
add_shortcode('one_fifth_last', 'karma_one_fifth_last');




/* 4 */
function karma_one_fourth( $atts, $content = null ) {
   return '[raw]<div class="one_fourth">[/raw]' . do_shortcode($content) . '[raw]</div>[/raw]';
}
add_shortcode('one_fourth', 'karma_one_fourth');


function karma_one_fourth_last( $atts, $content = null ) {
   return '[raw]<div class="one_fourth_last">[/raw]' . do_shortcode($content) . '[raw]</div><br class="clear" />[/raw]';
}
add_shortcode('one_fourth_last', 'karma_one_fourth_last');




/* 3 */
function karma_one_third( $atts, $content = null ) {
   return '[raw]<div class="one_third">[/raw]' . do_shortcode($content) . '[raw]</div>[/raw]';
}
add_shortcode('one_third', 'karma_one_third');


function karma_one_third_last( $atts, $content = null ) {
   return '[raw]<div class="one_third_last">[/raw]' . do_shortcode($content) . '[raw]</div><br class="clear" />[/raw]';
}
add_shortcode('one_third_last', 'karma_one_third_last');




/* 2 */
function karma_one_half( $atts, $content = null ) {
   return '[raw]<div class="one_half">[/raw]' . do_shortcode($content) . '[raw]</div>[/raw]';
}
add_shortcode('one_half', 'karma_one_half');


function karma_one_half_last( $atts, $content = null ) {
   return '[raw]<div class="one_half_last">[/raw]' . do_shortcode($content) . '[raw]</div><br class="clear" />[/raw]';
}
add_shortcode('one_half_last', 'karma_one_half_last');




/* 2/3 */
function karma_two_thirds( $atts, $content = null ) {
   return '[raw]<div class="two_thirds">[/raw]' . do_shortcode($content) . '[raw]</div>[/raw]';
}
add_shortcode('two_thirds', 'karma_two_thirds');


function karma_two_thirds_last( $atts, $content = null ) {
   return '[raw]<div class="two_thirds_last">[/raw]' . do_shortcode($content) . '[raw]</div><br class="clear" />[/raw]';
}
add_shortcode('two_thirds_last', 'karma_two_thirds_last');




/* 3/4 */
function karma_three_fourth( $atts, $content = null ) {
   return '[raw]<div class="three_fourth">[/raw]' . do_shortcode($content) . '[raw]</div>[/raw]';
}
add_shortcode('three_fourth', 'karma_three_fourth');


function karma_three_fourth_last( $atts, $content = null ) {
   return '[raw]<div class="three_fourth_last">[/raw]' . do_shortcode($content) . '[raw]</div><br class="clear" />[/raw]';
}
add_shortcode('three_fourth_last', 'karma_three_fourth_last');


function karma_flash_wrap( $atts, $content = null ) {
   return '[raw]<div class="flash_wrap">[/raw]' . do_shortcode($content) . '[raw]</div><br class="clear" />[/raw]';
}
add_shortcode('flash_wrap', 'karma_flash_wrap');
















/* ----- HORIZONTAL RULES ----- */
function karma_hr_shadow() {
    return '[raw]<hr class="hr_shadow" />[/raw]';
}
add_shortcode('hr_shadow', 'karma_hr_shadow');



function karma_hr() {
    return '[raw]<hr />[/raw]';
}
add_shortcode('hr', 'karma_hr');



function karma_top_link( $atts, $content = null ) {
   return '[raw]<hr /><a href="#" class="link-top">' . do_shortcode($content) . '</a><br class="clear" />[/raw]';
}
add_shortcode('top_link', 'karma_top_link');










/* ----- LISTS ----- */
function karma_list1( $atts, $content = null ) {
   return '<ul class="list">' . do_shortcode($content) . '</ul>';
}
add_shortcode('arrow_list', 'karma_list1');



function karma_list2( $atts, $content = null ) {
   return '<ul class="list list2">' . do_shortcode($content) . '</ul>';
}
add_shortcode('star_list', 'karma_list2');



function karma_list3( $atts, $content = null ) {
   return '<ul class="list list3">' . do_shortcode($content) . '</ul>';
}
add_shortcode('circle_list', 'karma_list3');



function karma_list4( $atts, $content = null ) {
   return '<ul class="list list4">' . do_shortcode($content) . '</ul>';
}
add_shortcode('check_list', 'karma_list4');













/* ----- ACCORDION ----- */
function karma_accordion( $atts, $content = null ) {
	extract(shortcode_atts(array(), $atts));

	
	$output .= '[raw]<ul class="accordion">[/raw]';
	$output .= do_shortcode($content) ;
	$output .= '[raw]</ul>[/raw]';
	return $output;
	
}
add_shortcode('accordion', 'karma_accordion');




function karma_slide( $atts, $content = null ) {
	extract(shortcode_atts(array(), $atts));
	$slide = $atts['name'];
	$output .= '[raw]<li><a href="#" class="opener"><strong>' .$slide. '</strong></a>[/raw]';
	$output .= '[raw]<div class="slide-holder"><div class="slide">[/raw]';
	
	$output .= '' . do_shortcode($content) .'';
	
	$output .= '[raw]</div></div></li>[/raw]';
	return $output;
}
add_shortcode('slide', 'karma_slide');











/* ----- TABS ----- */
$i = 0;
function karma_tab_set( $atts, $content = null ) {
	global $i;
	extract(shortcode_atts(array(), $atts));

	
	$output .= '[raw]<div class="tabs-area">[/raw]';
	
	$output .= '[raw]<ul class="tabset">[/raw]';
	foreach ($atts as $tab) {
		$tabID = "tab-" . $i++;
		$output .= '[raw]<li><a href="#' . $tabID . '" class="tab"><span>' .$tab. '</span></a></li>[/raw]';
	}
	$output .= '[raw]</ul>[/raw]';

	$output .= do_shortcode($content) .'[raw]</div>[/raw]';
	
	return $output;
	
}
add_shortcode('tabset', 'karma_tab_set');


$j = 0;
function karma_tabs( $atts, $content = null ) {
	global $j;
	extract(shortcode_atts(array(), $atts));
	$tabID = "tab-" . $j++;
	$output .= '[raw]<div id="' . $tabID . '" class="tab-box">[/raw]' . do_shortcode($content) .'[raw]</div>[/raw]';
	
	return $output;
}
add_shortcode('tab', 'karma_tabs');









/* ----- BUTTONS ----- */
function karma_button($atts, $content = null) {
  extract(shortcode_atts(array(
  'size' => '',
  'style' => '',
  'url' => 'http://www.',
  ), $atts));
  
  $size = ($size == 'small') ? 'small_' : $size;
  $size = ($size == 'medium') ? 'medium_' : $size;
  $size = ($size == 'large') ? 'large_' : $size;
  
  
  $output = '[raw]<a href="'.$url.'" class="ka_button '.$size.'button '.$size.$style.'"><span>' .do_shortcode($content). '</span></a><br class="clear" />[/raw]';
  return $output;
}
add_shortcode('button', 'karma_button');



/*  This version includes "target"

function karma_button($atts, $content = null) {
  extract(shortcode_atts(array(
  'size' => '',
  'style' => '',
  'url' => 'http://www.',
  'target' => '',
  ), $atts));
  
  $size = ($size == 'small') ? 'small_' : $size;
  $size = ($size == 'medium') ? 'medium_' : $size;
  $size = ($size == 'large') ? 'large_' : $size;
  $target = ($target == 'blank' || $target == 'self' || $target == 'parent'|| $target == 'top') ? $target : '';
  $target = ($target == 'blank') ? '_blank' : $target;
  $target = ($target == 'self') ? '_self' : $target;
  $target = ($target == 'parent') ? '_parent' : $target;
  $target = ($target == 'top') ? '_top' : $target;
  
  
  $output = '<a href="'.$url.'" class="ka_button '.$size.'button '.$size.$style.'" target="'.$target.'"><span>' .do_shortcode($content). '</span></a>';
  return $output;
}
add_shortcode('button', 'karma_button'); */









/* ----- TEXT CALLOUTS ----- */
function karma_callout1( $atts, $content = null ) {
   return '[raw]<div class="callout-wrap"><span>' . do_shortcode($content) . '</span></div><!-- end callout-wrap --><br class="clear" />
[/raw]';
}
add_shortcode('callout1', 'karma_callout1');


function karma_callout2( $atts, $content = null ) {
   return '[raw]<p class="callout2"><span>' . do_shortcode($content) . '</span></p><br class="clear" />[/raw]';
}
add_shortcode('callout2', 'karma_callout2');


function karma_green_callout( $atts, $content = null ) {
   return '[raw]<p class="message_green">' . do_shortcode($content) . '</p><br class="clear" />[/raw]';
}
add_shortcode('green_callout', 'karma_green_callout');


function karma_blue_callout( $atts, $content = null ) {
   return '[raw]<p class="message_blue">' . do_shortcode($content) . '</p><br class="clear" />[/raw]';
}
add_shortcode('blue_callout', 'karma_blue_callout');


function karma_red_callout( $atts, $content = null ) {
   return '[raw]<p class="message_red">' . do_shortcode($content) . '</p><br class="clear" />[/raw]';
}
add_shortcode('red_callout', 'karma_red_callout');


function karma_yellow_callout( $atts, $content = null ) {
   return '[raw]<p class="message_yellow">' . do_shortcode($content) . '</p><br class="clear" />[/raw]';
}
add_shortcode('yellow_callout', 'karma_yellow_callout');







/* ----- PRE-BUILT VIDEO LAYOUT ----- */
function karma_video_left( $atts, $content = null ) {
   return '[raw]<div class="video-wrap video_left">[/raw]' . do_shortcode($content) . '[raw]</div><!-- end video-wrap -->[/raw]';
}
add_shortcode('video_left', 'karma_video_left');

function karma_video_right( $atts, $content = null ) {
   return '[raw]<div class="video-wrap video_right">[/raw]' . do_shortcode($content) . '[raw]</div><!-- end video-wrap -->[/raw]';
}
add_shortcode('video_right', 'karma_video_right');

function karma_video_frame( $atts, $content = null ) {
   return '[raw]<div class="video-main">
	<div class="video-frame">' . do_shortcode($content) . '</div><!-- end video-frame -->
</div><!-- end video-main -->[/raw]';
}
add_shortcode('video_frame', 'karma_video_frame');

function karma_video_text( $atts, $content = null ) {
   return '[raw]<div class="video-sub">[/raw]' . do_shortcode($content) . '[raw]</div><!-- end video-sub --><br class="clear" />[/raw]';
}
add_shortcode('video_text', 'karma_video_text');







/* ----- PRE-BUILT 3D THUMBNAILS SMALL ----- */
function karma_3dthumbs_left( $atts, $content = null ) {
   return '[raw]<div class="three-d-wrap video_left">[/raw]' . do_shortcode($content) . '[raw]</div><!-- end three-d-wrap -->[/raw]';
}
add_shortcode('3d_thumbs_left', 'karma_3dthumbs_left');

function karma_3dthumbs_right( $atts, $content = null ) {
   return '[raw]<div class="three-d-wrap video_right">[/raw]' . do_shortcode($content) . '[raw]</div><!-- end three-d-wrap -->[/raw]';
}
add_shortcode('3d_thumbs_right', 'karma_3dthumbs_right');

function karma_3dthumbs_frame( $atts, $content = null ) {
   return '[raw]<div class="three-d-main">' . do_shortcode($content) . '</div><!-- end three-d-main -->[/raw]';
}
add_shortcode('3d_thumbs_frame', 'karma_3dthumbs_frame');

function karma_3dthumbs_text( $atts, $content = null ) {
   return '[raw]<div class="three-d-sub">[/raw]' . do_shortcode($content) . '[raw]</div><!-- end three-d-sub --><br class="clear" />[/raw]';
}
add_shortcode('3d_thumbs_text', 'karma_3dthumbs_text');









/* ----- MISCELLANEOUS SHORTCODES ----- */

/* iFrame */
function karma_iframe($atts, $content=null) {
extract(shortcode_atts(array(
'url'   => '',
'scrolling'     => 'no',
'width'     => '100%',
'height'    => '500',
'frameborder'   => '0',
'marginheight'  => '0',
), $atts));
 
if (empty($url)) return 'http://';
return '<iframe src="'.$url.'" title="" scrolling="'.$scrolling.'" width="'.$width.'" height="'.$height.'" frameborder="'.$frameborder.'" marginheight="'.$marginheight.'">'.$content.'</iframe>';
}
add_shortcode('iframe','karma_iframe');






/* related posts */
function related_posts_shortcode( $atts ) {
extract(shortcode_atts(array(
	'title' => '',
	'limit' => '5',
), $atts)); 
global $wpdb, $post, $table_prefix;
if ($post->ID) {
	$retval = '[raw]<div class="related_posts"><h4>'.$title.'</h4><ul class="list">[/raw]';
// Get tags
$tags = wp_get_post_tags($post->ID);
$tagsarray = array();
foreach ($tags as $tag) {
$tagsarray[] = $tag->term_id;
}
$tagslist = implode(',', $tagsarray);

// Do the query
$q = "
SELECT p.*, count(tr.object_id) as count
FROM $wpdb->term_taxonomy AS tt, $wpdb->term_relationships AS tr, $wpdb->posts AS p
WHERE tt.taxonomy ='post_tag'
AND tt.term_taxonomy_id = tr.term_taxonomy_id
AND tr.object_id  = p.ID
AND tt.term_id IN ($tagslist)
AND p.ID != $post->ID
AND p.post_status = 'publish'
AND p.post_date_gmt < NOW()
GROUP BY tr.object_id
ORDER BY count DESC, p.post_date_gmt DESC
LIMIT $limit;";

$related = $wpdb->get_results($q);
if ( $related ) {
	foreach($related as $r) {
		$retval .= '<li><a title="'.wptexturize($r->post_title).'" href="'.get_permalink($r->ID).'">'.wptexturize($r->post_title).'</a></li>';}
} else {
	$retval .= '<li>No related posts found</li>';}
$retval .= '[raw]</ul></div><!-- end related posts -->[/raw]';
return $retval;
}return;}
add_shortcode('related_posts', 'related_posts_shortcode');





/* related posts for content area */
function related_posts_content_shortcode( $atts ) {
extract(shortcode_atts(array(
	'title' => '',
	'limit' => '5',
), $atts)); 
global $wpdb, $post, $table_prefix;
if ($post->ID) {
	$retval = '<div class="related_posts"><h4>'.$title.'</h4><ul class="list">';
// Get tags
$tags = wp_get_post_tags($post->ID);
$tagsarray = array();
foreach ($tags as $tag) {
$tagsarray[] = $tag->term_id;
}
$tagslist = implode(',', $tagsarray);

// Do the query
$q = "
SELECT p.*, count(tr.object_id) as count
FROM $wpdb->term_taxonomy AS tt, $wpdb->term_relationships AS tr, $wpdb->posts AS p
WHERE tt.taxonomy ='post_tag'
AND tt.term_taxonomy_id = tr.term_taxonomy_id
AND tr.object_id  = p.ID
AND tt.term_id IN ($tagslist)
AND p.ID != $post->ID
AND p.post_status = 'publish'
AND p.post_date_gmt < NOW()
GROUP BY tr.object_id
ORDER BY count DESC, p.post_date_gmt DESC
LIMIT $limit;";

$related = $wpdb->get_results($q);
if ( $related ) {
	foreach($related as $r) {
		$retval .= '<li><a title="'.wptexturize($r->post_title).'" href="'.get_permalink($r->ID).'">'.wptexturize($r->post_title).'</a></li>';}
} else {
	$retval .= '<li>No related posts found</li>';}
$retval .= '</ul></div><!-- end related posts -->';
return $retval;
}return;}
add_shortcode('related_posts_content', 'related_posts_content_shortcode');











/* ----- TESTIMONIALS ----- */
function karma_testimonials( $atts, $content = null ) {
   return '[raw]<div class="testimonials">' . do_shortcode($content) . '</div><!-- END testimonials -->[/raw]';
}
add_shortcode('testimonial_wrap', 'karma_testimonials');


function karma_testimonial_content( $atts, $content = null ) {
   return '<blockquote><p>' . do_shortcode($content) . '</p></blockquote>';
}
add_shortcode('testimonial', 'karma_testimonial_content');

function karma_testimonial_client( $atts, $content = null ) {
   return '<cite>&ndash;' . do_shortcode($content) . '</cite>';
}
add_shortcode('client_name', 'karma_testimonial_client');






/* ----- CATEGORIES ----- */
function karma_categorie_display($atts) {
	extract(shortcode_atts(array(
'title'   => 'Categories',
), $atts));
	
	$pos_excluded = positive_exlcude_cats();
	$pos_cats = $pos_excluded;
	$pos_args = array('orderby' => 'name', 'exclude' => $pos_cats, 'title_li' => __( '' ));	
	echo '<h3>'.$title.'</h3>';
	wp_list_categories($pos_args);
}
add_shortcode('post_categories', 'karma_categorie_display');
?>
