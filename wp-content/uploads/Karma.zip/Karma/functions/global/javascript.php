<?php 
function karma_scripts() {
		wp_enqueue_script( 'jquery', KARMA_JS .'/jquery-1.4.2.min.js', array('jquery'));
		wp_enqueue_script( 'karma-custom', KARMA_JS .'/karma.js', array('jquery'));
		// wp_enqueue_script( 'cufon-custom', KARMA_JS .'/cufon.js', array('jquery'));		
}	
add_action('wp_print_scripts', 'karma_scripts');
?>