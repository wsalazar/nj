<?php

add_action('init','of_options');

if (!function_exists('of_options')) {
function of_options(){
	
// VARIABLES
$themename = "Karma";
$shortname = "ka";

// Populate siteoptions option in array for use in theme
global $of_options;
$of_options = get_option('of_options');
$GLOBALS['template_path'] = KARMA_FRAMEWORK;


//Access the WordPress Categories via an Array
$of_categories = array();  
$of_categories_obj = get_categories('hide_empty=0');
foreach ($of_categories_obj as $of_cat) {
    $of_categories[$of_cat->cat_ID] = $of_cat->cat_name;}
$categories_tmp = array_unshift($of_categories, "Select a category:");    
       

//Access the WordPress Pages via an Array
$of_pages = array();
$of_pages_obj = get_pages('sort_column=post_parent,menu_order');    
foreach ($of_pages_obj as $of_page) {
    $of_pages[$of_page->ID] = $of_page->post_name; }
$of_pages_tmp = array_unshift($of_pages, "Select the Blog page:");       


// Image Alignment radio box
$options_thumb_align = array("alignleft" => "Left","alignright" => "Right","aligncenter" => "Center"); 


// Image Links to Options
$options_image_link_to = array("image" => "The Image","post" => "The Post"); 


//More Options
$uploads_arr = wp_upload_dir();
$all_uploads_path = $uploads_arr['path'];
$all_uploads = get_option('of_uploads');
$other_entries = array("Select a number:","1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19");
$body_repeat = array("no-repeat","repeat-x","repeat-y","repeat");
$body_pos = array("top left","top center","top right","center left","center center","center right","bottom left","bottom center","bottom right");


//Footer Columns Array
$footer_columns = array("1","2","3","4","5","6");


//Paths for "type" => "images"
$url =  get_stylesheet_directory_uri() . '/functions/admin/images/color-schemes/';
$footerurl =  get_stylesheet_directory_uri() . '/functions/admin/images/footer-layouts/';


// Homepage Video Options
$layout_radio = array("layout_left" => "Left side","layout_right" => "Right Side");

		
// jQuery Cycle Pause Settings
$options_jcycle_controls = array("true" => "Yes", "0" => "No");


//Access the WordPress Categories via an Array
$exclude_categories = array();  
$exclude_categories_obj = get_categories('hide_empty=0');
foreach ($exclude_categories_obj as $exclude_cat) {
    $exclude_categories[$exclude_cat->cat_ID] = $exclude_cat->cat_name;} 













/*-----------------------------------------------------------------------------------*/
/* Create Site Options Array */
/*-----------------------------------------------------------------------------------*/
$options = array();

$options[] = array( "name" => "General Settings",
                    "type" => "heading");
					

$options[] = array( "name" => "Website Logo",
					"desc" => "Upload a custom logo for your Website.",
					"id" => $shortname."_sitelogo",
					"std" => "",
					"type" => "upload");
					
$options[] = array( "name" => "Login Screen Logo",
					"desc" => "Upload a custom logo for your Wordpress login screen.",
					"id" => $shortname."_loginlogo",
					"std" => "",
					"type" => "upload");
					
$options[] = array( "name" => "Favicon",
					"desc" => "Upload a 16px x 16px image that will represent your website's favicon.",
					"id" => $shortname."_favicon",
					"std" => "",
					"type" => "upload");
					
$options[] = array( "name" => "Hide Meta Boxes",
					"desc" => "This functionality will hide meta boxes in the Dashboard to help Wordpress feel more like a CMS. This includes: Comments, Discussion, Trackbacks, Custom Fields, Author, and Slug. <em>Un-check this box if you prefer not to include this functionality.</em>",
					"id" => $shortname."_hidemetabox",
					"std" => "true",
					"type" => "checkbox");
					
                                               
$options[] = array( "name" => "Tracking Code",
					"desc" => "Paste your Google Analytics (or other) tracking code here.",
					"id" => $shortname."_google_analytics",
					"std" => "",
					"type" => "textarea");
					
					
					
					
					
					
					
					
					
					
$options[] = array( "name" => "Styling Options",
					"type" => "heading");
				
$options[] = array( "name" => "Website Color Scheme",
					"desc" => "Select a color scheme for your website.",
					"id" => $shortname."_main_scheme",
					"std" => "",
					"type" => "images",
					"options" => array(
						'karma-dark' => $url . 'main-karma-dark.jpg',
						'karma-coffee' => $url . 'main-karma-coffee.jpg',
						'karma-teal-grey' => $url . 'main-karma-teal-grey.jpg',
						'karma-blue-grey' => $url . 'main-karma-blue-grey.jpg',
						'karma-autumn' => $url . 'main-karma-autumn.jpg',
						'karma-teal' => $url . 'main-karma-teal.jpg',
						'karma-grey' => $url . 'main-karma-grey.jpg',
						'karma-cherry' => $url . 'main-karma-cherry.jpg',
						'karma-purple' => $url . 'main-karma-purple.jpg',
						'karma-silver' => $url . 'main-karma-silver.jpg',
						'karma-fire' => $url . 'main-karma-fire.jpg',
						'karma-violet' => $url . 'main-karma-violet.jpg',
						'karma-royal-blue' => $url . 'main-karma-royal-blue.jpg',
						'karma-golden' => $url . 'main-karma-golden.jpg',
						'karma-periwinkle' => $url . 'main-karma-periwinkle.jpg',
						'karma-cool-blue' => $url . 'main-karma-cool-blue.jpg',
						'karma-lime-green' => $url . 'main-karma-lime-green.jpg',
						'karma-pink' => $url . 'main-karma-pink.jpg',
						'karma-sky-blue' => $url . 'main-karma-sky-blue.jpg',
						'karma-forest-green' => $url . 'main-karma-forest-green.jpg'
						
						
						));
$options[] = array( "name" => "Secondary Color Scheme",
					"desc" => "Select a secondary color scheme only if you wish to override the default secondary color.",
					"id" => $shortname."_secondary_scheme",
					"std" => "default",
					"type" => "images",
					"options" => array(
						'default' => $url . 'secondary-default.jpg',
						'secondary-coffee' => $url . 'secondary-coffee.jpg',
						'secondary-cherry' => $url . 'secondary-cherry.jpg',
						'secondary-autumn' => $url . 'secondary-autumn.jpg',
						'secondary-fire' => $url . 'secondary-fire.jpg',
						'secondary-golden' => $url . 'secondary-golden.jpg',
						'secondary-lime-green' => $url . 'secondary-lime-green.jpg',
						'secondary-purple' => $url . 'secondary-purple.jpg',
						'secondary-pink' => $url . 'secondary-pink.jpg',
						'secondary-violet' => $url . 'secondary-violet.jpg',
						'secondary-periwinkle' => $url . 'secondary-periwinkle.jpg',
						'secondary-teal' => $url . 'secondary-teal.jpg',
						'secondary-forest-green' => $url . 'secondary-forest-green.jpg',
						'secondary-teal-grey' => $url . 'secondary-teal-grey.jpg',
						'secondary-blue-grey' => $url . 'secondary-blue-grey.jpg',
						'secondary-royal-blue' => $url . 'secondary-royal-blue.jpg',
						'secondary-cool-blue' => $url . 'secondary-cool-blue.jpg',
						'secondary-sky-blue' => $url . 'secondary-sky-blue.jpg',
						'secondary-silver' => $url . 'secondary-silver.jpg',
						'secondary-dark' => $url . 'secondary-dark.jpg',
						'secondary-grey' => $url . 'secondary-grey.jpg'
						));
											
$options[] = array( "name" => "Custom CSS",
                    "desc" => "Use this text area if you wish to insert custom CSS into your website.",
                    "id" => $shortname."_custom_css",
                    "std" => "",
                    "type" => "textarea");
					
					
					
					
					
					
					
					
					
					
$options[] = array( "name" => "Interface Options",
					"type" => "heading");
					
$options[] = array( "name" => "Search Bar",
					"desc" => "By default, a search bar is displayed in the banner. <em>Un-check this box if you prefer not to include this functionality.</em>",
					"id" => $shortname."_searchbar",
					"std" => "true",
					"type" => "checkbox");
					
$options[] = array( "name" => "Search Bar Text",
					"desc" => "Customize the text that gets displayed in the search bar. You can simply leave this field blank if you won't be using the search functionality.",
					"id" => $shortname."_searchbartext",
					"std" => "Search",
					"type" => "text");
					
$options[] = array( "name" => "Breadcrumbs",
					"desc" => "By default, breadcrumbs are displayed in the banner. <em>Un-check this box if you prefer not to include this functionality.</em>",
					"id" => $shortname."_crumbs",
					"std" => "true",
					"type" => "checkbox");
					
$options[] = array( "name" => "Scroll to Top Link",
					"desc" => "By default, a link is added to the footer which smoothly scrolls to the top of the page when clicked by a user. <em>Un-check this box if you prefer not to include this functionality.</em>",
					"id" => $shortname."_scrolltoplink",
					"std" => "true",
					"type" => "checkbox");
					
$options[] = array( "name" => "Scroll to Top Label",
					"desc" => "Customize the text for the scroll-to-top link. <em>Simply leave this field blank if you won't be using the scroll-to-top functionality.</em>",
					"id" => $shortname."_scrolltoplinktext",
					"std" => "top",
					"type" => "text");
					
 $options[] = array( "name" => "Toolbar",
					"desc" => "Un-check this box if you would like to disable the toolbar above the main navigation.",
					"id" => $shortname."_toolbar",
					"std" => "true",
					"type" => "checkbox");
					
/* $options[] = array( "name" => "Toolbar Background Color",
					"desc" => "Set a custom background color for the toolbar.<br />(Leave this blank to use the default color scheme).",
					"id" => $shortname."_toolbar_color",
					"std" => "",
					"type" => "color"); */
					
$options[] = array( "name" => "Footer Style",
					"desc" => "Select a footer layout style.<br />(full, half, small)",
					"id" => $shortname."_footer_layout",
					"std" => "full_bottom",
					"type" => "images",
					"options" => array(
						'full_bottom' => $footerurl . 'footer-layout-1.png',
						'full' => $footerurl . 'footer-layout-2.png',
						'bottom' => $footerurl . 'footer-layout-3.png'
						));
						
$options[] = array( "name" => "Footer Columns",
					"desc" => "Select the number of columns you would like to display in the footer.",
					"id" => $shortname."_footer_columns",
					"std" => "4",
					"type" => "select",
					"options" => $footer_columns);
					
/* $options[] = array( "name" => "Portfolio Count",
					"desc" => "Enter the amount of items you would like to display on the portfolio page(s).",
					"id" => $shortname."_portfolio_count",
					"std" => "12",
					"type" => "text"); */

					
					
					
					
					
					
					
					
					
					
					
$options[] = array( "name" => "Blog Settings",
					"type" => "heading");
					
$options[] = array( "name" => "Blog Page",
					"desc" => "Select the page that will be used as your blog page.",
					"id" => $shortname."_blogpage",
					"std" => "",
					"type" => "select",
					"options" => $of_pages);

$options[] = array( "name" => "Banner Text",
					"desc" => "Set the page title that is displayed in the banner area of your Blog page.",
					"id" => $shortname."_blogtitle",
					"std" => "Blog",
					"type" => "text");
					
$options[] = array( "name" => "Button Text",
					"desc" => "Set the text for the buttons displayed after each blog post excerpt.",
					"id" => $shortname."_blogbutton",
					"std" => "Continue Reading &rarr;",
					"type" => "text");
					
$options[] = array( "name" => "Related Posts",
					"desc" => "By default, a list of related posts is displayed at the end of each blog post. <em>Un-check this box if you prefer not to include this functionality.</em>",
					"id" => $shortname."_related_posts",
					"std" => "true",
					"type" => "checkbox");
					
$options[] = array( "name" => "Related Posts Title",
					"desc" => "Enter the title that is displayed above the list of related posts. <em>Simply leave this field blank if you won't be using this functionality.</em>",
					"id" => $shortname."_related_posts_title",
					"std" => "Related Posts",
					"type" => "text");
					
$options[] = array( "name" => "Related Posts Count",
					"desc" => "Enter the amount of related posts you'd like to display. <em>Simply leave this field blank if you won't be using this functionality.</em>",
					"id" => $shortname."_related_posts_count",
					"std" => "5",
					"type" => "text");
					
$options[] = array( "name" => "About-the-Author",
					"desc" => "By default, the author's bio is displayed at the end of each blog post. <em>Un-check this box if you prefer not to include this functionality.</em> (Author bio's can be set in the Wordpress user profile page.<br>(<a href=\"profile.php\">Users > Your Profile</a>)",
					"id" => $shortname."_blogauthor",
					"std" => "true",
					"type" => "checkbox");
					
/* $options[] = array( "name" => "Drag-to-Share",
					"desc" => "By default, each blog post includes drag-to-share functionality. Drag-to-share provides your visitors with an interactive functionality to easily share blog posts on popular social networks. <em>Un-check this box if you prefer not to include this functionality.</em>",
					"id" => $shortname."_dragshare",
					"std" => "true",
					"type" => "checkbox"); */
					
					
$options[] = array( "name" => "Exclude Categories",
					"desc" => "Check off any post categories that you'd like to exclude from the blog.",
					"id" => $shortname."_blogexcludetest",
					"std" => "",
					"type" => "multicheck",
					"options" => $exclude_categories);
					
					
					
					
					
					
					
					
					
					
					
					
					
$options[] = array( "name" => "Homepage Settings",
					"type" => "heading");
					
	$options[] = array( "name" => "jQuery Homepage Template",
					"desc" => "Check this box to enable the \"Homepage :: jQuery\" page template.",
					"id" => $shortname."_jcycle_enable",
					"std" => "false",
					"type" => "checkbox");
					
$options[] = array( "name" => "jQuery Homepage Template (2)",
					"desc" => "Check this box to enable the \"Homepage :: jQuery 2\" page template.",
					"id" => $shortname."_jcycle_enable2",
					"std" => "false",
					"type" => "checkbox");
				
					
$options[] = array( "name" => "jQuery Homepage Post Category",
					"desc" => "Select the category that will be used for generating the jQuery slides.",
					"id" => $shortname."_jcycle_category",
					"std" => "Select a category:",
					"type" => "select",
					"options" => $of_categories);
			
					
/* $options[] = array( "name" => "jQuery Homepage Slides",
					"desc" => "Enter the number of slides you would like to display.",
					"id" => $shortname."_jcycle_slides",
					"std" => "5",
					"type" => "text"); */
					
$options[] = array( "name" => "jQuery Homepage Slider Time",
					"desc" => "Enter the desired amount of time you would like to display each slide. (milliseconds)",
					"id" => $shortname."_jcycle_timeout",
					"std" => "8000",
					"type" => "text");
					
$options[] = array( "name" => "jQuery Homepage Pause Settings",
					"desc" => "Would you like the slider to pause when the user hovers over a slide?",
					"id" => $shortname."_jcycle_pause_hover",
					"std" => "",
					"type" => "radio",
					"options" => $options_jcycle_controls);
					
					
$options[] = array( "name" => "3D CU3ER - Slider ID Number",
					"desc" => "Enter the ID number of the 3D slider you would like to embed on the \"Homepage :: 3D\" page template.<br><br><em>Not sure where to find the slider ID number? <a href=\"http://themes.5-squared.com/support/cu3er-instructions.html\" target=\"_blank\">View these visual instructions.</a></em>",
					"id" => $shortname."_cu3er_slider_id",
					"std" => "1",
					"type" => "text");
					
					
/* $options[] = array( "name" => "Video Embed Code - Homepage",
					"desc" => "Enter the embed code for the video you'd like to display.<br /><br /><em>Note: The dimensions of the video should be set to: 436px x 270px.</em>",
					"id" => $shortname."_video_embed_code",
					"std" => "<iframe src=\"http://player.vimeo.com/video/8245346\" title=\"\" scrolling=\"no\" width=\"436\" height=\"270\" frameborder=\"0\" marginheight=\"0\"></iframe>",
					"type" => "textarea");
					
					
$options[] = array( "name" => "Video Content - Homepage",
					"desc" => "Select the category that will be used for the content next to the video.<br /><br /><em>Note: This category should only contain one post.</em>",
					"id" => $shortname."_video_category",
					"std" => "Select a category:",
					"type" => "select",
					"options" => $of_categories); */
					
					





					

					
					
					
					
					
					
					
					
					
					
					
					
					$options[] = array( "name" => "Javascript Settings",
					"type" => "heading");				



					
$options[] = array( "name" => "Enable Testimonial Slider",
					"desc" => "Check this box to enable the testimonial slider.",
					"id" => $shortname."_testimonial_enable",
					"std" => "false",
					"type" => "checkbox");
					
$options[] = array( "name" => "Testimonial Slider Time",
					"desc" => "Enter the desired amount of time you would like to display each testimonial. (milliseconds)",
					"id" => $shortname."_testimonial_timeout",
					"std" => "8000",
					"type" => "text");
					
$options[] = array( "name" => "Testimonial Slider Pause Settings",
					"desc" => "Would you like the testimonial slider to pause when the user hovers over a slide?",
					"id" => $shortname."_testimonial_pause_hover",
					"std" => "",
					"type" => "radio",
					"options" => $options_jcycle_controls);
					
					

					

				
				
				
				
				
/* $options[] = array( "name" => "Contact Settings",
					"type" => "heading");

$options[] = array( "name" => "Email Address",
					"desc" => "Enter the E-mail address where you would like the contact form to be sent.",
					"id" => $shortname."_contact_sendto",
					"std" => "you@yourdomain.com",
					"type" => "text");
					
$options[] = array( "name" => "Email Subject Line",
					"desc" => "Customize the subject line that will appear in your inbox.",
					"id" => $shortname."_contact_subjectline",
					"std" => "[Wordpress] Message from our website",
					"type" => "text");
					
$options[] = array( "name" => "Required Text",
					"desc" => "Customize the text that will be displayed next to the required fields.",
					"id" => $shortname."_contact_required",
					"std" => "(required)",
					"type" => "text");
					
$options[] = array( "name" => "[Form Field] - Name",
					"desc" => "Customize the label that will be displayed for the 'Name' field.",
					"id" => $shortname."_contact_namefield",
					"std" => "Your Name:",
					"type" => "text");
					
$options[] = array( "name" => "[Form Field] - Email Address",
					"desc" => "Customize the label that will be displayed for the 'Email Address' field.",
					"id" => $shortname."_contact_emailfield",
					"std" => "Email Address:",
					"type" => "text");
					
$options[] = array( "name" => "[Form Field] - Comments",
					"desc" => "Customize the label that will be displayed for the 'Comments' field.",
					"id" => $shortname."_contact_commentfield",
					"std" => "Comments:",
					"type" => "text"); 
					
$options[] = array( "name" => "[Error Message] - Blank Name",
					"desc" => "Customize the error message that will be displayed when a user leaves the 'Name' field blank.",
					"id" => $shortname."_contact_errorname",
					"std" => "Please enter your name.",
					"type" => "textarea");
					
$options[] = array( "name" => "[Error Message] - Invalid Email Address",
					"desc" => "Customize the error message that will be displayed when a user enters an invalid email address.",
					"id" => $shortname."_contact_erroremail",
					"std" => "Please enter a valid E-mail address.",
					"type" => "textarea"); 
					
$options[] = array( "name" => "Success Message",
					"desc" => "Customize the success message that will be displayed after the user submits the form.",
					"id" => $shortname."_contact_successmsg",
					"std" => "Thank you for messaging us. We will get back to you as soon as possible. Cheers!",
					"type" => "textarea"); */
					
					
					
					
					
					
					
					
					$options[] = array( "name" => "Other Settings",
					"type" => "heading");
					
$options[] = array( "name" => "Contact Form(s): Required Text",
					"desc" => "Customize the text that will be displayed next to the required fields.",
					"id" => $shortname."_contact_required",
					"std" => "(required)",
					"type" => "text");
					
$options[] = array( "name" => "Contact Form(s): Success Message",
					"desc" => "Customize the success message that will be displayed after the user submits the form.",
					"id" => $shortname."_contact_successmsg",
					"std" => "Thank you for messaging us. We will get back to you as soon as possible. Cheers!",
					"type" => "textarea");
					
$options[] = array( "name" => "404 Page Banner Text",
					"desc" => "Set the page title that is displayed in the banner area of the 404 Error Page.",
					"id" => $shortname."_404title",
					"std" => "Page not Found",
					"type" => "text");
					
$options[] = array( "name" => "404 Message",
					"desc" => "Set the message that is displayed on the 404 Error Page.",
					"id" => $shortname."_404message",
					"std" => "Our Apologies, but the page you are looking for could not be found. Here are some links that you might find useful:
					<ul>
					<li><a href=\"http://www.\">Home</a></li>
					<li><a href=\"http://www.\">Sitemap</a></li>
					<li><a href=\"http://www.\">Contact Us</a></li>
					</ul>",
					"type" => "textarea");
					
$options[] = array( "name" => "Search Results Banner Text",
					"desc" => "Set the page title that is displayed in the banner area of the Search Results Page.",
					"id" => $shortname."_results_title",
					"std" => "Search Results",
					"type" => "text");
					
$options[] = array( "name" => "Search Results Fallback Message",
					"desc" => "Set the message that is displayed when a search comes back with no results.",
					"id" => $shortname."_results_fallback",
					"std" => "<p>Our Apologies, but your search did not return any results. Please try using a different search term.</p>",
					"type" => "textarea");
					
					
					
					
					
					
					
					
					

					



					
					
					
					
					
					
					
					
					/* BEGIN DISABLE (see how the first release goes)
					
					
					$options[] = array( "name" => "Video",
					"type" => "heading");
					
					
$options[] = array( "name" => "Video Position",
					"desc" => "Set the position of the Video/Image.",
					"id" => $shortname."_video_layout",
					"std" => "",
					"type" => "radio",
					"options" => $video_radio);

					
$options[] = array( "name" => "Video Embed Code",
					"desc" => "Input the video embed code here. The dimensions of the video player should be set to: <strong>572px x 312px</strong>.",
					"id" => $shortname."_video_content",
					"std" => "<iframe src=\"http://player.vimeo.com/video/14117794\" width=\"572\" height=\"312\" frameborder=\"0\"></iframe>",
					"type" => "textarea");
					
$options[] = array( "name" => "Image Upload",
					"desc" => "If you prefer to display an image rather than a video, you can upload it here. The dimensions are: <strong>572px x 312px.</strong>",
					"id" => $shortname."_video_image",
					"std" => "",
					"type" => "upload");
					
					$options[] = array( "name" => "Intro Text",
					"desc" => "This is the intro text that will appear next to your video/image.",
					"id" => $shortname."_video_text",
					"std" => "<h2>Title Goes Here</h2>
<p>Content Goes here</p>
[button size=\"medium\" style=\"black\" url=\"http://www.\" target=\"self\"]Button Text Goes Here[/button]",
					"type" => "textarea");
					
					
$options[] = array( "name" => "Callout Text",
					"desc" => "This is the larger text that spans the full width of the page.",
					"id" => $shortname."_video_callout",
					"std" => "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus blandit arcu eget velit laoreet commodo a et tortor. Cras eu quam quam, ut ultricies felis.",
					"type" => "textarea");
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					$options[] = array( "name" => "3D Thumbnails",
					"type" => "heading");
					
					
$options[] = array( "name" => "CU3ER Position",
					"desc" => "Set the position of the 3D Thumbnail CU3ER.",
					"id" => $shortname."_cu3er_3d_layout",
					"std" => "",
					"type" => "radio",
					"options" => $video_radio);

					
$options[] = array( "name" => "CU3ER Slider",
					"desc" => "Enter only the ID of the slider you wish to display. You can retrieve the ID by clicking <em>CU3ER > Edit.</em>",
					"id" => $shortname."_cu3er_3d_slider",
					"std" => "1",
					"type" => "text");
					
					$options[] = array( "name" => "Intro Text",
					"desc" => "This is the intro text that will appear next to your 3D slider.",
					"id" => $shortname."_cu3er_3d_text",
					"std" => "<h2>Title Goes Here</h2>
<p>Content Goes here</p>
[button size=\"medium\" style=\"black\" url=\"http://www.\" target=\"self\"]Button Text Goes Here[/button]",
					"type" => "textarea");
					
					
$options[] = array( "name" => "Callout Text",
					"desc" => "This is the larger text that spans the full width of the page.",
					"id" => $shortname."_cu3er_3d_callout",
					"std" => "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus blandit arcu eget velit laoreet commodo a et tortor. Cras eu quam quam, ut ultricies felis.",
					"type" => "textarea");
					
					
					
					END DISABLE */
					
					
					
					

update_option('of_template',$options); 					  
update_option('of_themename',$themename);   
update_option('of_shortname',$shortname);

}
}
?>