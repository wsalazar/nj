<?php

/* These are functions specific to the included option settings and this theme */

/*-----------------------------------------------------------------------------------*/
/* Theme Header Output - wp_head() */
/*-----------------------------------------------------------------------------------*/

// This sets up the layouts and styles selected from the options panel

if (!function_exists('siteoptions_wp_head')) {
	function siteoptions_wp_head() { 
		$shortname = "ka";
	    echo '<link href="'. KARMA_HOME . '/style.css' .'" rel="stylesheet" type="text/css" />'."\n";
		//Styles
	          $GLOBALS['main_stylesheet'] = get_option('ka_main_scheme');
	          if($GLOBALS['main_stylesheet'] != '')
	               echo '<link href="'. KARMA_CSS . $GLOBALS['main_stylesheet'] .'.css'.'" rel="stylesheet" type="text/css" />'."\n"; 
				   
				   $GLOBALS['secondary_stylesheet'] = get_option('ka_secondary_scheme');
	          if($GLOBALS['secondary_stylesheet'] != 'default')
	               echo '<link href="'. KARMA_CSS . $GLOBALS['secondary_stylesheet'] .'.css'.'" rel="stylesheet" type="text/css" />'."\n";               		  
	     }       
			
	}

add_action('wp_head', 'siteoptions_wp_head');


/*-----------------------------------------------------------------------------------*/
/* Output Custom CSS */
/*-----------------------------------------------------------------------------------*/

function karma_css() {
	$GLOBALS['custom_css'] = get_option('ka_custom_css');
	          if($GLOBALS['custom_css'] != '')
	        echo '<style type="text/css">'.  $GLOBALS['custom_css'] .'</style>'."\n";
	    }

add_action('wp_head', 'karma_css');



/*-----------------------------------------------------------------------------------*/
/* Add Favicon
/*-----------------------------------------------------------------------------------*/

function karma_favicon() {
	$GLOBALS['favicon'] = get_option('ka_favicon');
	          if($GLOBALS['favicon'] != '')
	        echo '<link rel="shortcut icon" href="'.  $GLOBALS['favicon'] .'"/>'."\n";
	    }

add_action('wp_head', 'karma_favicon');





/*-----------------------------------------------------------------------------------*/
/* Add analytics code to footer */
/*-----------------------------------------------------------------------------------*/

function karma_analytics(){
	
	$GLOBALS['google'] = get_option('ka_google_analytics');
	          if($GLOBALS['google'] != '')
		echo stripslashes($GLOBALS['google']) . "\n";
}
add_action('wp_footer','karma_analytics');



/*-----------------------------------------------------------------------------------
Add drag-to-share to footer (if_enabled)
-----------------------------------------------------------------------------------

function karma_share(){
	
	$GLOBALS['dragshare'] = get_option('ka_dragshare');
	          if($GLOBALS['dragshare'] == "true" && is_home() || is_single())  
			  include (TEMPLATEPATH . '/functions/content/click-drag.php');

		
}
add_action('wp_footer','karma_share');
*/





/*-----------------------------------------------------------------------------------*/
/* Add jQuery Cycle (if_enabled) */
/*-----------------------------------------------------------------------------------*/

function karma_jcycle(){
	$GLOBALS['jcycle_enable'] = get_option('ka_jcycle_enable');
	          if($GLOBALS['jcycle_enable'] == "true" && is_page_template('template-homepage-jquery.php')){
			  echo '<script type="text/javascript" src="'.KARMA_JS.'/jquery.cycle.all.min.js"></script>';
			  include (TEMPLATEPATH . '/functions/content/jquery-cycle.php');}else{}

		
}
add_action('wp_footer','karma_jcycle');






/*-----------------------------------------------------------------------------------*/
/* Add jQuery Cycle 2 (if_enabled) */
/*-----------------------------------------------------------------------------------*/

function karma_jcycle2(){
	$GLOBALS['jcycle_enable2'] = get_option('ka_jcycle_enable2');
	          if($GLOBALS['jcycle_enable2'] == "true" && is_page_template('template-homepage-jquery-2.php')){
			  echo '<script type="text/javascript" src="'.KARMA_JS.'/jquery.cycle.all.min.js"></script>';
			  include (TEMPLATEPATH . '/functions/content/jquery-cycle-2.php');}else{}

		
}
add_action('wp_footer','karma_jcycle2');






/*-----------------------------------------------------------------------------------*/
/* Add Testimonial Slider (if_enabled) */
/*-----------------------------------------------------------------------------------*/

function karma_testimonial(){
	$GLOBALS['testimonial_enable'] = get_option('ka_testimonial_enable');
	          if($GLOBALS['testimonial_enable'] == "true"){
			  echo '<script type="text/javascript" src="'.KARMA_JS.'/jquery.cycle.all.min.js"></script>';
			  include (TEMPLATEPATH . '/functions/content/jquery-testimonials.php');
	}
}
add_action('wp_footer','karma_testimonial');










/*-----------------------------------------------------------------------------------*/
/* Hide Meta Boxes (if_enabled) */
/*-----------------------------------------------------------------------------------*/
function karma_metaboxes(){
	$GLOBALS['hide_metaboxes'] = get_option('ka_hidemetabox');
	          if($GLOBALS['hide_metaboxes'] == "true"){
				  
				  
/* pages */
remove_meta_box('commentstatusdiv','page','normal'); // Comments
remove_meta_box('commentsdiv','page','normal'); // Comments
remove_meta_box('trackbacksdiv','page','normal'); // Trackbacks
remove_meta_box('postcustom','page','normal'); // Custom Fields
remove_meta_box('authordiv','page','normal'); // Author
remove_meta_box('slugdiv','page','normal'); // Slug

/* posts */
remove_meta_box('commentsdiv','post','normal'); // Comments
remove_meta_box('postcustom','post','normal'); // Custom Fields
remove_meta_box('slugdiv','post','normal'); // Slug

		
}
}
add_action('admin_head','karma_metaboxes');
?>