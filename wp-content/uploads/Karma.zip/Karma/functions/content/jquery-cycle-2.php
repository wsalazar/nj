<?php 
$jcycle_timeout = get_option('ka_jcycle_timeout');
$jcycle_pause_hover = get_option('ka_jcycle_pause_hover');
echo '<script type="text/javascript">
//<![CDATA[
$(window).load(function() {
	$(\'.home-banner-wrap ul\').css("background-image", "none");
	$(\'.jqslider\').css("display", "block");
	$(\'.big-banner #main .main-area\').css("padding-top", "16px");
    $(\'.home-banner-wrap ul\').after(\'<div class="jquery-pager">&nbsp;</div>\').cycle({
		fx: \'fade\',
		timeout: '.$jcycle_timeout.',
		height: \'auto\',
		pause: '.$jcycle_pause_hover.',
		pager: \'.jquery-pager\',
		cleartypeNoBg: true

	});
});
//]]>
</script>';
?>
