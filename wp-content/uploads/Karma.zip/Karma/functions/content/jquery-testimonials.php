<?php 
$testimonial_timeout = get_option('ka_testimonial_timeout');
$testimonial_pause_hover = get_option('ka_testimonial_pause_hover');
//The &nbsp; in testimonial-pager is to solve an issue where IE won't display the controls if the div is empty.
echo '<script type="text/javascript">
//<![CDATA[
$(document).ready(function() {
	function onAfter(curr, next, opts, fwd) {
var index = opts.currSlide;
$(\'#prev,#prev2,#prev3,#prev4,#prev5\')[index == 0 ? \'hide\' : \'show\']();
$(\'#next,#next2,#next3,#next4,#next5\')[index == opts.slideCount - 1 ? \'hide\' : \'show\']();
//get the height of the current slide
var $ht = $(this).height();
//set the container\'s height to that of the current slide
$(this).parent().animate({height: $ht});
}
    $(\'.testimonials\').after(\'<div class="testimonial-pager">&nbsp;</div>\').cycle({
		fx: \'fade\',
		timeout: '.$testimonial_timeout.',
		height: \'auto\',
		pause: '.$testimonial_pause_hover.',
		pager: \'.testimonial-pager\',
		before: onAfter,
		cleartypeNoBg: true

	});
});

//]]>
</script>';
?>
