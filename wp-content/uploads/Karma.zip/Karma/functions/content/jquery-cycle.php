<?php 
$jcycle_timeout = get_option('ka_jcycle_timeout');
$jcycle_pause_hover = get_option('ka_jcycle_pause_hover');
//The &nbsp; in jquery-pager is to solve an issue where IE won't display the controls if the div is empty. This is becuase apparently since the div is empty, the hasLAyout property is set to false.
echo '<script type="text/javascript">
//<![CDATA[
$(window).load(function() {
	$(\'.home-bnr-jquery ul\').css("background-image", "none");
	$(\'.jqslider\').css("display", "block");
    $(\'.home-bnr-jquery ul\').after(\'<div class="jquery-pager">&nbsp;</div>\').cycle({
		fx: \'fade\',
		timeout: '.$jcycle_timeout.',
		height: \'auto\',
		pause: '.$jcycle_pause_hover.',
		pager: \'.jquery-pager\',
		cleartypeNoBg: true

	});
});
//]]>
</script>';
?>
