<?php 
$nivo_slices = get_option('ka_nivo_slices');
$nivo_animation = get_option('ka_nivo_animation');
$nivo_speed = get_option('ka_nivo_speed');
$nivo_pause = get_option('ka_nivo_pause');
$nivo_pause_hover = get_option('ka_nivo_pause_hover');
$nivo_arrow = get_option('ka_nivo_arrow');
$nivo_arrows_hover = get_option('ka_nivo_arrows_hover');
$nivo_controls = get_option('ka_nivo_controls');

echo '
	<script type="text/javascript">
//<![CDATA[
$(window).load(function() {
    $(\'#nivo-slider\').nivoSlider({
        effect:\''.$nivo_animation.'\',
        slices:'.$nivo_slices.',
        animSpeed:'.$nivo_speed.',
        pauseTime:'.$nivo_pause.',
        startSlide:0,
        directionNav:'.$nivo_arrow.',
        directionNavHide:'.$nivo_arrows_hover.',
        keyboardNav:true,
        pauseOnHover:true,
        manualAdvance:false,
        captionOpacity:0.8,'.$nivo_controls.'
    });
});
//]]>
</script>';	
?>