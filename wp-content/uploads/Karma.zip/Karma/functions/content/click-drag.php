<script type="text/javascript">
//<![CDATA[

var $ = jQuery.noConflict();
$(document).ready(function() 
{

//cache selector
var images = $(".post_share"),
 title = $("title").text() || document.title;

   //make images draggable
   images.draggable({

 //create draggable helper
 helper: function() {
   return $("<div>").attr("id", "helper").html("").appendTo("body");
 },
 cursor: "pointer",
 cursorAt: { left: 0, top: 28 },
 zIndex: 99999,

 //show overlay and targets
 start: function() {
$("<div>").attr("id", "overlay").css("opacity", 0.7).appendTo("body");
$("#tip").remove();
$(this).unbind("mouseenter");
$("#targets").css("left", ($("body").width() / 2) - $("#targets").width() / 2).slideDown();
 },

 //remove targets and overlay
 stop: function() {
$("#targets").slideUp();
$(".share", "#targets").remove();
$("#overlay").remove();

$(this).bind("mouseenter", createTip);
 }
});

//make targets droppable
$("#targets li").droppable({
 tolerance: "pointer",
 //show info when over target
 over: function() {
   $(".share", "#targets").remove();
   $("<span>").addClass("share").text("Share on " + $(this).attr("id")).addClass("active").appendTo($(this)).fadeIn();
 },

drop: function() {
var id = $(this).attr("id"),
currentUrl = window.location.href,
baseUrl = $(this).find("a").attr("href");

 

if (id.indexOf("twitter") != -1) {
 window.location.href = baseUrl + "/home?status=" + title + ": " + currentUrl;
} else if (id.indexOf("delicious") != -1) {
 window.location.href = baseUrl + "/save?url=" + currentUrl + "&title=" + title;
} else if (id.indexOf("facebook") != -1) {
 window.location.href = baseUrl + "/sharer.php?u=" + currentUrl + "&t=" + title;
} else if (id.indexOf("digg") != -1) {
 window.location.href = baseUrl + "/submit?phase=2&url=" + currentUrl + "&title=" + title;
}
 }
});

 
var createTip = function(e) {
 //create tool tip if it doesn't exist
 ($("#tip").length === 0) ? $("<div>").html("<span>&nbsp;<\/span><span class='arrow'><\/span>").attr("id", "tip").css({ left:e.pageX + 30, top:e.pageY - 16 }).appendTo("body").fadeIn(800) : null;
};

images.bind("mouseenter", createTip);
images.mousemove(function(e) {
 //move tooltip
		  $("#tip").css({ left:e.pageX + 30, top:e.pageY - 16 });

		});
   images.mouseleave(function() {
 //remove tooltip
 $("#tip").remove();
   });
 });
//]]>   
</script>
<p style="display:none;"><img src="<?php bloginfo('template_url'); ?>/images/_global/bg-ui-targets.png" alt="#" />
<img src="<?php bloginfo('template_url'); ?>/images/_global/bg-ui-drop.png" alt="#" /></p>
<div id="targets">
<ul>
<li id="twitter"><a href="http://twitter.com">twitter</a></li>
<li id="delicious"><a href="http://delicious.com">delicious</a></li>
<li id="facebook"><a href="http://www.facebook.com">facebook</a></li>
<li id="digg"><a href="http://www.digg.com">digg</a></li>
</ul>
</div>