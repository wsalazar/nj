<?php

/* ADD MENUS FUNCTIONALITY */
if (function_exists('add_theme_support')) {
    add_theme_support('nav-menus');
}


/* REGISTER MENU */
register_nav_menu('Primary Navigation', 'Main Navigation');




/* ACTIVATE POST THUMBNAILS */
if ( function_exists( 'add_theme_support' ) ){
add_theme_support( 'post-thumbnails' , array( 'post' ));
}
?>